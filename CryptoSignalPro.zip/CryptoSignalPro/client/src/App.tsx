import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { useState, useEffect } from "react";
import { getCurrentUser } from "./lib/firebase";
import { fetchUserProfile } from "./lib/api";
import { User } from "./types";
import MainLayout from "./components/layouts/MainLayout";

// Pages
import Dashboard from "@/pages/dashboard";
import Market from "@/pages/market";
import AIPredictions from "@/pages/ai-predictions";
import WhaleAlerts from "@/pages/whale-alerts";
import Calculator from "@/pages/calculator-minimal";
import Watchlist from "@/pages/watchlist";
import Subscription from "@/pages/subscription";
import CoinDetails from "@/pages/coin/[id]";
import Login from "@/pages/login";
import Admin from "@/pages/admin";

function Router() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [location] = useLocation();

  useEffect(() => {
    const loadUser = async () => {
      try {
        setLoading(true);
        const firebaseUser = await getCurrentUser();
        
        if (firebaseUser) {
          const userProfile = await fetchUserProfile();
          setUser(userProfile);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    loadUser();
  }, [location]);

  // Public routes
  const publicRoutes = ["/login"];
  const isPublicRoute = publicRoutes.includes(location);

  // If loading, show nothing
  if (loading) {
    return null;
  }

  // DEVELOPMENT MODE: Allow access without authentication
  const isDevelopment = import.meta.env.DEV;
  const bypassAuth = isDevelopment;
  
  // Only redirect to login in production or when not bypassing auth
  if (!isPublicRoute && !user && location !== "/login" && !bypassAuth) {
    window.location.href = "/login";
    return null;
  }

  // Admin route check
  if (location.startsWith("/admin") && (!user || !user.isAdmin)) {
    return <NotFound />;
  }

  return (
    <MainLayout user={user}>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/market" component={Market} />
        <Route path="/ai-predictions" component={AIPredictions} />
        <Route path="/whale-alerts" component={WhaleAlerts} />
        <Route path="/calculator" component={Calculator} />
        <Route path="/watchlist" component={Watchlist} />
        <Route path="/subscription" component={Subscription} />
        <Route path="/coin/:id" component={CoinDetails} />
        <Route path="/login" component={Login} />
        <Route path="/admin" component={Admin} />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
