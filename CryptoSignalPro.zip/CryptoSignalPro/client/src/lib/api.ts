import { apiRequest } from "./queryClient";
import type { Coin, CoinDetail, AIPrediction, WhaleAlert, SubscriptionPlan, User } from "../types";

// Coin API
export const fetchCoins = async (): Promise<Coin[]> => {
  const response = await fetch('/api/coins');
  if (!response.ok) {
    throw new Error('Failed to fetch coins');
  }
  return response.json();
};

export const fetchCoinDetails = async (id: string): Promise<CoinDetail> => {
  const response = await fetch(`/api/coins/${id}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch coin details for ${id}`);
  }
  return response.json();
};

export const fetchCoinHistory = async (id: string, days: number = 7): Promise<{ prices: [number, number][] }> => {
  const response = await fetch(`/api/coins/${id}/history?days=${days}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch coin history for ${id}`);
  }
  return response.json();
};

// AI Predictions API
export const fetchPredictions = async (): Promise<AIPrediction[]> => {
  const response = await fetch('/api/predictions');
  if (!response.ok) {
    throw new Error('Failed to fetch AI predictions');
  }
  return response.json();
};

export const fetchCoinPrediction = async (coinId: string): Promise<AIPrediction> => {
  const response = await fetch(`/api/predictions/${coinId}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch prediction for ${coinId}`);
  }
  return response.json();
};

// Whale Alerts API
export const fetchWhaleAlerts = async (limit: number = 10): Promise<WhaleAlert[]> => {
  const response = await fetch(`/api/whale-alerts?limit=${limit}`);
  if (!response.ok) {
    throw new Error('Failed to fetch whale alerts');
  }
  return response.json();
};

export const fetchWhaleAlertsByToken = async (token: string, limit: number = 10): Promise<WhaleAlert[]> => {
  const response = await fetch(`/api/whale-alerts?token=${token}&limit=${limit}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch whale alerts for ${token}`);
  }
  return response.json();
};

// User API
export const fetchUserProfile = async (): Promise<User | null> => {
  try {
    const response = await fetch('/api/user/profile');
    if (!response.ok) {
      // In development mode, just return null for user profile
      if (import.meta.env.DEV) {
        console.warn('No authenticated user found, using development mode');
        return null;
      }
      throw new Error('Failed to fetch user profile');
    }
    return response.json();
  } catch (error) {
    // In development mode, allow the app to continue without an authenticated user
    if (import.meta.env.DEV) {
      console.warn('Error fetching user profile, continuing in development mode');
      return null;
    }
    throw error;
  }
};

export const updateUserProfile = async (data: Partial<User>): Promise<User> => {
  const response = await apiRequest('PATCH', '/api/user/profile', data);
  return response.json();
};

// Watchlist API
export const fetchWatchlist = async (): Promise<Coin[]> => {
  const response = await fetch('/api/user/watchlist');
  if (!response.ok) {
    throw new Error('Failed to fetch watchlist');
  }
  return response.json();
};

export const addToWatchlist = async (coinId: string): Promise<void> => {
  await apiRequest('POST', '/api/user/watchlist', { coinId });
};

export const removeFromWatchlist = async (coinId: string): Promise<void> => {
  await apiRequest('DELETE', `/api/user/watchlist/${coinId}`);
};

// Subscription API
export const fetchSubscriptionPlans = async (): Promise<SubscriptionPlan[]> => {
  const response = await fetch('/api/subscriptions/plans');
  if (!response.ok) {
    throw new Error('Failed to fetch subscription plans');
  }
  return response.json();
};

export const fetchUserSubscription = async (): Promise<{tier: string, subscriptionId: string | null}> => {
  const response = await fetch('/api/user/subscription');
  if (!response.ok) {
    throw new Error('Failed to fetch user subscription');
  }
  return response.json();
};

// Admin API
export const fetchAllUsers = async (): Promise<User[]> => {
  const response = await fetch('/api/admin/users');
  if (!response.ok) {
    throw new Error('Failed to fetch users');
  }
  return response.json();
};

export const updateUserSubscription = async (userId: number, tier: string): Promise<User> => {
  const response = await apiRequest('PATCH', `/api/admin/users/${userId}/subscription`, { tier });
  return response.json();
};

// Calculator API
export const convertCrypto = async (from: string, to: string, amount: number): Promise<{ amount: number }> => {
  const response = await fetch(`/api/calculator/convert?from=${from}&to=${to}&amount=${amount}`);
  if (!response.ok) {
    throw new Error('Failed to convert currencies');
  }
  return response.json();
};
