// Import Firebase modules
import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "firebase/auth";

// Check if Firebase credentials are available
const hasFirebaseCredentials = 
  import.meta.env.VITE_FIREBASE_API_KEY && 
  import.meta.env.VITE_FIREBASE_PROJECT_ID && 
  import.meta.env.VITE_FIREBASE_APP_ID;

let auth: any = null;
let app: any = null;
let googleProvider: any = null;

// Initialize Firebase only if credentials are available
if (hasFirebaseCredentials) {
  const firebaseConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
    appId: import.meta.env.VITE_FIREBASE_APP_ID,
  };
  
  // Initialize Firebase
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  googleProvider = new GoogleAuthProvider();
}

// Authentication Functions
export const signInWithGoogle = async () => {
  if (!hasFirebaseCredentials) {
    console.error("Firebase credentials not available");
    throw new Error("Firebase authentication is not configured. Please use email/password login instead.");
  }
  
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    // Send the Firebase ID token to your backend
    const idToken = await user.getIdToken();
    await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ idToken }),
    });
    return user;
  } catch (error) {
    console.error("Error signing in with Google: ", error);
    throw error;
  }
};

export const signUpWithEmail = async (email: string, password: string) => {
  if (!hasFirebaseCredentials) {
    console.error("Firebase credentials not available");
    // Use direct API call to our backend instead
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email, 
          password,
          username: email.split('@')[0],
          displayName: email.split('@')[0] 
        }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Registration failed");
      }
      
      return await response.json();
    } catch (error) {
      console.error("Error signing up with email: ", error);
      throw error;
    }
  }
  
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error signing up with email: ", error);
    throw error;
  }
};

export const signInWithEmail = async (email: string, password: string) => {
  if (!hasFirebaseCredentials) {
    console.error("Firebase credentials not available");
    // Use direct API call to our backend instead
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Login failed");
      }
      
      return await response.json();
    } catch (error) {
      console.error("Error signing in with email: ", error);
      throw error;
    }
  }
  
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error signing in with email: ", error);
    throw error;
  }
};

export const signOut = async () => {
  try {
    if (hasFirebaseCredentials && auth) {
      await firebaseSignOut(auth);
    }
    
    // Clear server-side session
    await fetch('/api/auth/logout', { method: 'POST' });
    
    // Reload the page to reset state
    window.location.href = '/login';
  } catch (error) {
    console.error("Error signing out: ", error);
    throw error;
  }
};

export const getCurrentUser = (): Promise<FirebaseUser | null> => {
  return new Promise((resolve) => {
    if (!hasFirebaseCredentials || !auth) {
      // No Firebase credentials, so no auth state to track
      resolve(null);
      return;
    }
    
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      unsubscribe();
      resolve(user);
    });
  });
};

export { auth };
