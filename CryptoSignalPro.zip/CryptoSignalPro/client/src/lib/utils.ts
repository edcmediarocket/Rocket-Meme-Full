import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number, currency: string = "USD", compact: boolean = false): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    notation: compact ? 'compact' : 'standard',
    maximumFractionDigits: currency === 'USD' ? 2 : 8
  }).format(amount);
}

export function formatPercentage(percent: number): string {
  return `${percent > 0 ? '+' : ''}${percent.toFixed(2)}%`;
}

export function formatNumber(num: number, compact: boolean = false): string {
  return new Intl.NumberFormat('en-US', {
    notation: compact ? 'compact' : 'standard',
    maximumFractionDigits: 2
  }).format(num);
}

export function shortenAddress(address: string, chars: number = 4): string {
  return `${address.substring(0, chars)}...${address.substring(address.length - chars)}`;
}

export function formatTimeAgo(date: Date | string): string {
  const now = new Date();
  const diffInMs = now.getTime() - (typeof date === 'string' ? new Date(date).getTime() : date.getTime());
  
  const seconds = Math.floor(diffInMs / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days} day${days !== 1 ? 's' : ''} ago`;
  if (hours > 0) return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
  if (minutes > 0) return `${minutes} min${minutes !== 1 ? 's' : ''} ago`;
  return `${seconds} sec${seconds !== 1 ? 's' : ''} ago`;
}

export function getSignalColor(signal: string): string {
  switch (signal.toLowerCase()) {
    case 'strong buy':
    case 'buy':
      return 'text-neon-green';
    case 'strong sell':
    case 'sell':
      return 'text-neon-red';
    case 'hold':
    case 'neutral':
      return 'text-neon-yellow';
    default:
      return 'text-stellar-white';
  }
}

export function getRiskColor(risk: string): string {
  switch (risk.toLowerCase()) {
    case 'low':
      return 'text-neon-green';
    case 'medium':
      return 'text-neon-yellow';
    case 'high':
      return 'text-neon-red';
    default:
      return 'text-stellar-white';
  }
}

export function canAccessTier(userTier: string, requiredTier: string): boolean {
  const tiers = { 'Basic': 1, 'Pro': 2, 'Premium': 3 };
  return tiers[userTier as keyof typeof tiers] >= tiers[requiredTier as keyof typeof tiers];
}
