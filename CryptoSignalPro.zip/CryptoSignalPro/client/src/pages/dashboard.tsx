import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { fetchUserProfile } from "@/lib/api";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Bell, RefreshCw, Plus } from "lucide-react";
import RocketAnimation from "@/components/common/RocketAnimation";
import MarketOverview from "@/components/dashboard/MarketOverview";
import AIPredictions from "@/components/dashboard/AIPredictions";
import WhaleAlerts from "@/components/dashboard/WhaleAlerts";
import CryptoCalculator from "@/components/dashboard/CryptoCalculator";
import SubscriptionPlans from "@/components/subscription/SubscriptionPlans";

export default function Dashboard() {
  const { data: user, isLoading } = useQuery({
    queryKey: ['/api/user/profile'],
    queryFn: fetchUserProfile
  });

  return (
    <div>
      {/* Dashboard Header */}
      <div className="mb-8 flex flex-col lg:flex-row lg:items-center justify-between">
        <div>
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Dashboard</h2>
          {isLoading ? (
            <div className="h-4 w-48">
              <Skeleton className="h-4 w-48" />
            </div>
          ) : (
            <p className="text-stellar-gray text-sm">
              {user ? (
                `Welcome back, ${user?.displayName || user?.username}! Here's your crypto overview`
              ) : (
                "Welcome to Rocket Meme! Here's your crypto overview"
              )}
            </p>
          )}
        </div>
        
        <div className="flex space-x-2 mt-4 lg:mt-0">
          <Button variant="outline" size="sm" className="flex items-center bg-space-blue hover:bg-neon-blue/20 border-neon-blue/20">
            <Bell className="h-4 w-4 mr-1" />
            Alerts
          </Button>
          <Button variant="outline" size="sm" className="flex items-center bg-space-blue hover:bg-neon-pink/20 border-neon-pink/20">
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
          <Button size="sm" className="flex items-center bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90">
            <Plus className="h-4 w-4 mr-1" />
            Add Asset
          </Button>
        </div>
      </div>

      {/* Marketing Banner (Premium Features) */}
      <div className="mb-8 relative overflow-hidden rounded-xl">
        <div className="absolute inset-0 bg-gradient-to-r from-space-blue to-neon-blue/20 z-0"></div>
        <div className="relative z-10 p-6 lg:p-8 flex flex-col lg:flex-row items-center justify-between">
          <div className="mb-4 lg:mb-0">
            <h3 className="text-xl lg:text-2xl font-orbitron font-bold mb-2">Upgrade to Premium</h3>
            <p className="text-stellar-gray max-w-md">
              Unlock advanced AI predictions, exclusive whale alerts, and more premium features!
            </p>
            <div className="flex mt-4 gap-2">
              <Link href="/subscription">
                <Button className="bg-neon-pink text-space-darkBlue hover:bg-neon-pink/90">
                  Upgrade Now
                </Button>
              </Link>
              <Button variant="outline" className="border-neon-blue/50 hover:bg-neon-blue/10">
                Learn More
              </Button>
            </div>
          </div>
          {/* Rocket Animation */}
          <RocketAnimation size="lg" />
        </div>
      </div>

      {/* Dashboard Components */}
      <MarketOverview />
      <AIPredictions />
      <WhaleAlerts />
      <CryptoCalculator />

      {/* Subscription Plans */}
      <section>
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <span className="material-icons mr-2 text-neon-green">workspace_premium</span>
          Subscription Plans
        </h3>
        
        <SubscriptionPlans />
      </section>
    </div>
  );
}
