import { useQuery } from "@tanstack/react-query";
import { fetchUserSubscription } from "@/lib/api";
import { Award, CheckCircle, Info } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import SubscriptionPlans from "@/components/subscription/SubscriptionPlans";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function Subscription() {
  const { data: subscription, isLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });

  return (
    <div>
      <div className="mb-8 flex flex-col lg:flex-row lg:items-center justify-between">
        <div>
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Subscription Plans</h2>
          <p className="text-stellar-gray text-sm">
            {isLoading ? (
              <Skeleton className="h-4 w-48" />
            ) : (
              `Your current plan: ${subscription?.tier || "Basic"}`
            )}
          </p>
        </div>
      </div>

      {/* Explanation Card */}
      <div className="glassmorphism rounded-xl p-6 mb-6 border border-neon-blue/30">
        <div className="flex items-start">
          <Award className="h-8 w-8 text-neon-green mr-3 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-orbitron font-semibold mb-2">Subscription Benefits</h3>
            <p className="text-stellar-gray text-sm mb-4">
              Upgrade your subscription to unlock premium features and advanced tools. Our tiered pricing model gives you 
              access to more powerful insights as you upgrade.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="p-3 rounded-lg bg-space-blue/30">
                <div className="flex items-center mb-2">
                  <span className="text-neon-blue font-orbitron font-bold mr-2">Basic</span>
                  <span className="px-2 py-0.5 text-xs rounded-full bg-neon-blue/20 text-neon-blue">$9.99/mo</span>
                </div>
                <p className="text-xs text-stellar-gray">Essential features for beginners</p>
              </div>
              
              <div className="p-3 rounded-lg bg-space-blue/30">
                <div className="flex items-center mb-2">
                  <span className="text-neon-blue font-orbitron font-bold mr-2">Pro</span>
                  <span className="px-2 py-0.5 text-xs rounded-full bg-neon-blue/20 text-neon-blue">$24.99/mo</span>
                </div>
                <p className="text-xs text-stellar-gray">Advanced tools for serious traders</p>
              </div>
              
              <div className="p-3 rounded-lg bg-space-blue/30">
                <div className="flex items-center mb-2">
                  <span className="text-neon-pink font-orbitron font-bold mr-2">Premium</span>
                  <span className="px-2 py-0.5 text-xs rounded-full bg-neon-pink/20 text-neon-pink">$49.99/mo</span>
                </div>
                <p className="text-xs text-stellar-gray">Complete suite of exclusive features</p>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-3 text-xs">
              <div className="flex items-center px-2 py-1 rounded-full bg-neon-green/20 text-neon-green">
                <CheckCircle className="h-3 w-3 mr-1" />
                <span className="font-medium">Secure Payments</span>
              </div>
              <div className="flex items-center px-2 py-1 rounded-full bg-neon-green/20 text-neon-green">
                <CheckCircle className="h-3 w-3 mr-1" />
                <span className="font-medium">Cancel Anytime</span>
              </div>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center px-2 py-1 rounded-full bg-neon-blue/20 text-neon-blue cursor-help">
                      <Info className="h-3 w-3 mr-1" />
                      <span className="font-medium">PayPal Integration</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="bg-space-blue border-neon-blue/30 text-stellar-white">
                    <p>All payments are processed securely through PayPal</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </div>

      {/* Subscription Plans */}
      <SubscriptionPlans />
    </div>
  );
}
