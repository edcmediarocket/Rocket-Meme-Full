import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchCoins } from "@/lib/api";
import { Calculator as CalculatorIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";

export default function Calculator() {
  const [fromCurrency, setFromCurrency] = useState("BTC");
  const [toCurrency, setToCurrency] = useState("USD");
  const [amount, setAmount] = useState("1");
  const [convertedAmount, setConvertedAmount] = useState<number | null>(null);
  
  const { data: coins, isLoading: coinsLoading } = useQuery({
    queryKey: ['/api/coins'],
    queryFn: fetchCoins,
  });

  const handleCalculate = () => {
    if (!coins || !amount || isNaN(parseFloat(amount))) return;

    const fromCoin = coins.find(c => c.symbol.toUpperCase() === fromCurrency.toUpperCase() || c.id === fromCurrency.toLowerCase());
    const toCoin = coins.find(c => c.symbol.toUpperCase() === toCurrency.toUpperCase() || c.id === toCurrency.toLowerCase());
    
    // Handle fiat currencies
    const isFiatFrom = ["USD", "EUR", "JPY", "GBP", "AUD"].includes(fromCurrency);
    const isFiatTo = ["USD", "EUR", "JPY", "GBP", "AUD"].includes(toCurrency);
    
    let fromPrice = isFiatFrom ? 1 : fromCoin?.current_price || 0;
    let toPrice = isFiatTo ? 1 : toCoin?.current_price || 0;
    
    // Different calculation logic based on currency types
    let result: number;
    
    if (isFiatFrom && isFiatTo) {
      // Fiat to fiat (using simple conversion rates for demo)
      const rates: Record<string, number> = {
        "USD": 1,
        "EUR": 0.93,
        "JPY": 150.3,
        "GBP": 0.79,
        "AUD": 1.53
      };
      result = parseFloat(amount) * (rates[toCurrency] / rates[fromCurrency]);
    } else if (isFiatFrom) {
      // Fiat to crypto
      result = parseFloat(amount) / toPrice;
    } else if (isFiatTo) {
      // Crypto to fiat
      result = parseFloat(amount) * fromPrice;
    } else {
      // Crypto to crypto
      result = parseFloat(amount) * (fromPrice / toPrice);
    }
    
    setConvertedAmount(result);
  };

  const getCoinPrice = (symbol: string): number => {
    if (["USD", "EUR", "JPY", "GBP", "AUD"].includes(symbol)) {
      return 1; // Fiat currencies
    }
    
    const coin = coins?.find(c => c.symbol.toUpperCase() === symbol.toUpperCase());
    return coin?.current_price || 0;
  };

  if (coinsLoading) {
    return (
      <div>
        <div className="mb-8">
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Crypto Calculator</h2>
          <p className="text-stellar-gray text-sm">Convert between cryptocurrencies and fiat currencies</p>
        </div>
        
        <div className="glassmorphism rounded-xl p-6 mb-6">
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  // Common currency options without using SelectItem
  const cryptoOptions = ["BTC", "ETH", "XRP", "ADA", "DOGE", "SHIB", "SOL"];
  const fiatOptions = ["USD", "EUR", "JPY", "GBP", "AUD"];

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Simple Crypto Calculator</h2>
        <p className="text-stellar-gray text-sm">Convert between cryptocurrencies and fiat currencies</p>
      </div>

      <div className="glassmorphism rounded-xl p-6 mb-6 border border-neon-blue/30">
        <div className="flex items-start">
          <CalculatorIcon className="h-8 w-8 text-neon-pink mr-3 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-orbitron font-semibold mb-2">About the Converter</h3>
            <p className="text-stellar-gray text-sm mb-4">
              This simplified calculator uses real-time market data to convert between different cryptocurrencies and fiat currencies.
            </p>
          </div>
        </div>
      </div>
      
      <div className="glassmorphism rounded-xl p-6 neon-border">
        <div className="grid grid-cols-1 gap-6">
          {/* Calculator Inputs */}
          <div>
            <div className="mb-4">
              <label className="block text-sm text-stellar-gray mb-2">From Currency</label>
              <div className="flex gap-2 mb-4">
                <div className="flex-1">
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-space-midnight border border-neon-blue/20 rounded-lg focus:border-neon-blue"
                  />
                </div>
                
                <div className="flex-1">
                  <select 
                    value={fromCurrency} 
                    onChange={(e) => setFromCurrency(e.target.value)}
                    className="w-full bg-space-blue text-white border border-neon-blue/20 rounded-lg focus:border-neon-blue h-10 px-3"
                  >
                    <optgroup label="Cryptocurrencies">
                      {cryptoOptions.map(crypto => (
                        <option key={crypto} value={crypto}>{crypto}</option>
                      ))}
                    </optgroup>
                    <optgroup label="Fiat Currencies">
                      {fiatOptions.map(fiat => (
                        <option key={fiat} value={fiat}>{fiat}</option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              </div>
              
              <label className="block text-sm text-stellar-gray mb-2">To Currency</label>
              <div className="flex gap-2 mb-4">
                <div className="flex-1">
                  <Input
                    type="text"
                    value={convertedAmount !== null ? convertedAmount.toString() : ''}
                    readOnly
                    className="w-full bg-space-midnight border border-neon-blue/20 rounded-lg focus:border-neon-blue"
                  />
                </div>
                
                <div className="flex-1">
                  <select 
                    value={toCurrency} 
                    onChange={(e) => setToCurrency(e.target.value)}
                    className="w-full bg-space-blue text-white border border-neon-blue/20 rounded-lg focus:border-neon-blue h-10 px-3"
                  >
                    <optgroup label="Cryptocurrencies">
                      {cryptoOptions.map(crypto => (
                        <option key={crypto} value={crypto}>{crypto}</option>
                      ))}
                    </optgroup>
                    <optgroup label="Fiat Currencies">
                      {fiatOptions.map(fiat => (
                        <option key={fiat} value={fiat}>{fiat}</option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              </div>
              
              <Button 
                onClick={handleCalculate}
                className="w-full py-3 rounded-lg bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90 font-medium"
              >
                Calculate
              </Button>
            </div>
          </div>
          
          {/* Common Conversions */}
          <div>
            <h4 className="font-semibold mb-3">Common Crypto Prices</h4>
            <div className="space-y-3">
              {cryptoOptions.slice(0, 5).map((symbol) => {
                const price = getCoinPrice(symbol);
                
                return (
                  <div key={symbol} className="flex justify-between items-center p-3 rounded-lg bg-space-midnight">
                    <div>
                      <span>1 {symbol}</span>
                    </div>
                    <div className="flex items-center">
                      <span>=</span>
                      <span className="ml-2">
                        {formatCurrency(price, "USD")} USD
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}