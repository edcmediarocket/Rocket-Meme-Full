import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchCoins } from "@/lib/api";
import { Calculator as CalculatorIcon, SquareSplitVertical, Search, Info } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function Calculator() {
  const [fromCurrency, setFromCurrency] = useState("BTC");
  const [toCurrency, setToCurrency] = useState("USD");
  const [amount, setAmount] = useState("1");
  const [convertedAmount, setConvertedAmount] = useState<number | null>(null);
  const [filterQuery, setFilterQuery] = useState("");
  
  const { data: coins, isLoading: coinsLoading } = useQuery({
    queryKey: ['/api/coins'],
    queryFn: fetchCoins,
  });

  const handleSwapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    setConvertedAmount(null); // Reset on swap
  };

  const handleCalculate = () => {
    if (!coins || !amount || isNaN(parseFloat(amount))) return;

    const fromCoin = coins.find(c => c.symbol.toUpperCase() === fromCurrency.toUpperCase() || c.id === fromCurrency.toLowerCase());
    const toCoin = coins.find(c => c.symbol.toUpperCase() === toCurrency.toUpperCase() || c.id === toCurrency.toLowerCase());
    
    // Handle fiat currencies
    const isFiatFrom = ["USD", "EUR", "JPY", "GBP", "AUD"].includes(fromCurrency);
    const isFiatTo = ["USD", "EUR", "JPY", "GBP", "AUD"].includes(toCurrency);
    
    let fromPrice = isFiatFrom ? 1 : fromCoin?.current_price || 0;
    let toPrice = isFiatTo ? 1 : toCoin?.current_price || 0;
    
    // Different calculation logic based on currency types
    let result: number;
    
    if (isFiatFrom && isFiatTo) {
      // Fiat to fiat (using simple conversion rates for demo)
      const rates: Record<string, number> = {
        "USD": 1,
        "EUR": 0.93,
        "JPY": 150.3,
        "GBP": 0.79,
        "AUD": 1.53
      };
      result = parseFloat(amount) * (rates[toCurrency] / rates[fromCurrency]);
    } else if (isFiatFrom) {
      // Fiat to crypto
      result = parseFloat(amount) / toPrice;
    } else if (isFiatTo) {
      // Crypto to fiat
      result = parseFloat(amount) * fromPrice;
    } else {
      // Crypto to crypto
      result = parseFloat(amount) * (fromPrice / toPrice);
    }
    
    setConvertedAmount(result);
  };

  // Prepare currency options
  const cryptoCurrencies = coins 
    ? coins
        .filter(coin => 
          !filterQuery || 
          coin.name.toLowerCase().includes(filterQuery.toLowerCase()) || 
          coin.symbol.toLowerCase().includes(filterQuery.toLowerCase())
        )
        .map(coin => ({
          // Ensure value is never empty to prevent SelectItem errors
          value: coin.symbol.toUpperCase() || "placeholder",
          label: `${coin.name} (${coin.symbol.toUpperCase()})`
        }))
    : [];
    
  const fiatCurrencies = [
    { value: "USD", label: "US Dollar (USD)" },
    { value: "EUR", label: "Euro (EUR)" },
    { value: "JPY", label: "Japanese Yen (JPY)" },
    { value: "GBP", label: "British Pound (GBP)" },
    { value: "AUD", label: "Australian Dollar (AUD)" }
  ];

  const commonConversions = [
    { from: "BTC", to: "USD", fromDisplay: "₿", fromBg: "bg-[#F7931A]" },
    { from: "ETH", to: "USD", fromDisplay: "Ξ", fromBg: "bg-[#627EEA]" },
    { from: "DOGE", to: "USD", fromDisplay: "Ð", fromBg: "bg-[#C3A634]" },
    { from: "USDT", to: "USD", fromDisplay: "₮", fromBg: "bg-[#26A17B]" },
    { from: "SHIB", to: "USD", fromDisplay: "🐕", fromBg: "bg-[#E42D04]" },
  ];

  if (coinsLoading) {
    return (
      <div>
        <div className="mb-8">
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Crypto Calculator</h2>
          <p className="text-stellar-gray text-sm">Convert between cryptocurrencies and fiat currencies</p>
        </div>
        
        <div className="glassmorphism rounded-xl p-6 mb-6">
          <Skeleton className="h-32 w-full" />
        </div>
        
        <div className="glassmorphism rounded-xl p-6 neon-border">
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  const getCoinPrice = (symbol: string): number => {
    if (["USD", "EUR", "JPY", "GBP", "AUD"].includes(symbol)) {
      return 1; // Fiat currencies
    }
    
    const coin = coins?.find(c => c.symbol.toUpperCase() === symbol.toUpperCase());
    return coin?.current_price || 0;
  };

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Crypto Calculator</h2>
        <p className="text-stellar-gray text-sm">Convert between cryptocurrencies and fiat currencies</p>
      </div>

      {/* Explanation Card */}
      <div className="glassmorphism rounded-xl p-6 mb-6 border border-neon-blue/30">
        <div className="flex items-start">
          <CalculatorIcon className="h-8 w-8 text-neon-pink mr-3 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-orbitron font-semibold mb-2">About the Converter</h3>
            <p className="text-stellar-gray text-sm mb-4">
              This calculator uses real-time market data to convert between different cryptocurrencies and fiat currencies.
              You can calculate the value of your crypto holdings or plan your trades by checking current conversion rates.
            </p>
            <div className="flex flex-wrap gap-3 text-xs">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center px-2 py-1 rounded-full bg-neon-blue/20 text-neon-blue cursor-help">
                      <Info className="h-3 w-3 mr-1" />
                      <span className="font-medium">Data Source</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="bg-space-blue border-neon-blue/30 text-stellar-white">
                    <p>Prices are sourced from CoinGecko API</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </div>
      
      <div className="glassmorphism rounded-xl p-6 neon-border">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Calculator Inputs */}
          <div>
            <div className="mb-4">
              <label className="block text-sm text-stellar-gray mb-2">From</label>
              <div className="flex">
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-space-midnight border border-neon-blue/20 rounded-l-lg focus:border-neon-blue"
                />
                <Select value={fromCurrency} onValueChange={setFromCurrency}>
                  <SelectTrigger className="w-40 bg-space-blue border border-neon-blue/20 rounded-r-lg focus:border-neon-blue">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="p-2">
                      <div className="relative mb-2">
                        <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-stellar-gray" />
                        <Input
                          placeholder="Search currencies..."
                          value={filterQuery}
                          onChange={(e) => setFilterQuery(e.target.value)}
                          className="pl-8 py-1 h-8"
                        />
                      </div>
                    </div>
                    <div className="max-h-[200px] overflow-auto">
                      <div className="p-1">
                        <div className="text-xs text-gray-500 px-2 py-1">Fiat Currencies</div>
                        {fiatCurrencies.map(currency => (
                          <SelectItem key={currency.value} value={currency.value}>{currency.label}</SelectItem>
                        ))}
                      </div>
                      
                      <div className="p-1">
                        <div className="text-xs text-gray-500 px-2 py-1">Cryptocurrencies</div>
                        {cryptoCurrencies.map(currency => (
                          <SelectItem key={currency.value} value={currency.value}>{currency.label}</SelectItem>
                        ))}
                      </div>
                    </div>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mb-4 flex justify-center">
              <Button
                onClick={handleSwapCurrencies}
                variant="outline"
                size="icon"
                className="w-10 h-10 rounded-full bg-space-blue hover:bg-neon-blue/20 border-none"
              >
                <SquareSplitVertical className="h-5 w-5" />
              </Button>
            </div>
            
            <div>
              <label className="block text-sm text-stellar-gray mb-2">To</label>
              <div className="flex">
                <Input
                  type="text"
                  value={convertedAmount !== null ? convertedAmount.toString() : ''}
                  readOnly
                  className="w-full bg-space-midnight border border-neon-blue/20 rounded-l-lg focus:border-neon-blue"
                />
                <Select value={toCurrency} onValueChange={setToCurrency}>
                  <SelectTrigger className="w-40 bg-space-blue border border-neon-blue/20 rounded-r-lg focus:border-neon-blue">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="p-2">
                      <div className="relative mb-2">
                        <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-stellar-gray" />
                        <Input
                          placeholder="Search currencies..."
                          value={filterQuery}
                          onChange={(e) => setFilterQuery(e.target.value)}
                          className="pl-8 py-1 h-8"
                        />
                      </div>
                    </div>
                    <div className="max-h-[200px] overflow-auto">
                      <div className="p-1">
                        <div className="text-xs text-gray-500 px-2 py-1">Fiat Currencies</div>
                        {fiatCurrencies.map(currency => (
                          <SelectItem key={currency.value} value={currency.value}>{currency.label}</SelectItem>
                        ))}
                      </div>
                      
                      <div className="p-1">
                        <div className="text-xs text-gray-500 px-2 py-1">Cryptocurrencies</div>
                        {cryptoCurrencies.map(currency => (
                          <SelectItem key={currency.value} value={currency.value}>{currency.label}</SelectItem>
                        ))}
                      </div>
                    </div>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mt-4">
              <Button 
                onClick={handleCalculate}
                className="w-full py-3 rounded-lg bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90 font-medium"
              >
                Calculate
              </Button>
            </div>
          </div>
          
          {/* Common Conversions */}
          <div>
            <h4 className="font-semibold mb-3">Common Conversions</h4>
            <div className="space-y-3">
              {commonConversions.map((conversion, index) => {
                const price = getCoinPrice(conversion.from);
                
                return (
                  <div key={index} className="flex justify-between items-center p-3 rounded-lg bg-space-midnight">
                    <div>
                      <div className="flex items-center">
                        <div className={`w-6 h-6 rounded-full ${conversion.fromBg} flex items-center justify-center mr-2 text-xs`}>
                          {conversion.fromDisplay}
                        </div>
                        <span>1 {conversion.from}</span>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span>=</span>
                      <span className="ml-2">
                        {formatCurrency(price, conversion.to)} {conversion.to}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-6 text-sm text-stellar-gray p-3 rounded-lg bg-space-blue/50">
              <p className="mb-2 font-medium text-stellar-white">Price Calculation Method:</p>
              <ul className="list-disc pl-4 space-y-1">
                <li>Crypto to Fiat: Multiply by current market price</li>
                <li>Fiat to Crypto: Divide by current market price</li>
                <li>Crypto to Crypto: Based on relative market prices in USD</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
