import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { fetchCoinDetails, fetchCoinHistory, fetchCoinPrediction, fetchWhaleAlertsByToken, fetchUserSubscription } from "@/lib/api";
import { formatCurrency, formatPercentage, canAccessTier, getSignalColor, getRiskColor } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useState } from "react";
import { 
  Sparkles, 
  TrendingUp, 
  ArrowLeft, 
  ExternalLink, 
  Star, 
  Brain, 
  Waves, 
  Info,
  AlertCircle,
  Lock,
  BarChart4
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { addToWatchlist, removeFromWatchlist } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

export default function CoinDetails() {
  const [match, params] = useRoute<{ id: string }>("/coin/:id");
  const coinId = params?.id || "";
  const [chartPeriod, setChartPeriod] = useState(7); // 7 days default
  
  // Fetch coin details
  const { data: coin, isLoading: coinLoading } = useQuery({
    queryKey: [`/api/coins/${coinId}`],
    queryFn: () => fetchCoinDetails(coinId),
    enabled: !!coinId,
  });
  
  // Fetch coin price history
  const { data: history, isLoading: historyLoading } = useQuery({
    queryKey: [`/api/coins/${coinId}/history`, chartPeriod],
    queryFn: () => fetchCoinHistory(coinId, chartPeriod),
    enabled: !!coinId,
  });
  
  // Fetch AI prediction
  const { data: prediction, isLoading: predictionLoading } = useQuery({
    queryKey: [`/api/predictions/${coinId}`],
    queryFn: () => fetchCoinPrediction(coinId),
    enabled: !!coinId,
  });
  
  // Fetch whale alerts for this token
  const { data: whaleAlerts, isLoading: whaleAlertsLoading } = useQuery({
    queryKey: [`/api/whale-alerts`, coinId],
    queryFn: () => fetchWhaleAlertsByToken(coinId, 5),
    enabled: !!coinId,
  });
  
  // Fetch user subscription
  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });
  
  // Fetch watchlist to check if this coin is in it
  const { data: watchlist } = useQuery({
    queryKey: ['/api/user/watchlist'],
    queryFn: () => fetchWatchlist,
  });
  
  const isInWatchlist = watchlist?.some(watchlistCoin => watchlistCoin.id === coinId);
  const userTier = subscription?.tier || "Basic";
  
  // Process chart data
  const chartData = history?.prices?.map(([timestamp, price]: [number, number]) => ({
    date: new Date(timestamp).toLocaleDateString(),
    price: price,
  }));
  
  const handleWatchlist = async () => {
    try {
      if (isInWatchlist) {
        await removeFromWatchlist(coinId);
        toast({
          title: "Removed from watchlist",
          description: `${coin?.name} has been removed from your watchlist.`,
        });
      } else {
        await addToWatchlist(coinId);
        toast({
          title: "Added to watchlist",
          description: `${coin?.name} has been added to your watchlist.`,
        });
      }
      
      // Invalidate watchlist query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/user/watchlist'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error updating your watchlist.",
        variant: "destructive",
      });
    }
  };
  
  const isLoading = coinLoading || historyLoading || predictionLoading || subscriptionLoading;
  
  if (isLoading) {
    return (
      <div>
        <div className="mb-4 flex gap-2">
          <Link href="/dashboard">
            <Button variant="outline" size="sm" className="bg-space-blue hover:bg-space-blue/80 border-neon-blue/20">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
          </Link>
          <Link href="/market">
            <Button variant="outline" size="sm" className="bg-space-blue hover:bg-space-blue/80 border-neon-blue/20">
              <TrendingUp className="mr-2 h-4 w-4" /> View Market
            </Button>
          </Link>
        </div>
        
        <div className="glassmorphism rounded-xl p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div className="flex items-center mb-4 md:mb-0">
              <Skeleton className="h-12 w-12 rounded-full mr-3" />
              <div>
                <Skeleton className="h-7 w-36 mb-1" />
                <Skeleton className="h-4 w-16" />
              </div>
            </div>
            <div className="flex items-center">
              <Skeleton className="h-10 w-40 mr-3" />
              <Skeleton className="h-10 w-10 rounded-full" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
            <Skeleton className="h-24 rounded-lg" />
          </div>
          
          <Skeleton className="h-72 w-full" />
        </div>
        
        <div className="glassmorphism rounded-xl p-6">
          <Skeleton className="h-8 w-48 mb-6" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }
  
  if (!coin) {
    return (
      <div className="glassmorphism rounded-xl p-8 text-center">
        <AlertCircle className="h-12 w-12 mx-auto text-neon-red mb-3" />
        <h3 className="text-xl font-semibold mb-2">Coin not found</h3>
        <p className="text-stellar-gray mb-6">The cryptocurrency you're looking for doesn't exist or couldn't be loaded.</p>
        <Link href="/market">
          <Button className="bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Market
          </Button>
        </Link>
      </div>
    );
  }
  
  // Check if prediction is available and if user can access it
  const predictionAvailable = prediction !== undefined;
  const canAccessPrediction = predictionAvailable && canAccessTier(userTier, prediction.requiredTier);
  
  return (
    <div>
      <div className="mb-4 flex gap-2">
        <Link href="/dashboard">
          <Button variant="outline" size="sm" className="bg-space-blue hover:bg-space-blue/80 border-neon-blue/20">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Button>
        </Link>
        <Link href="/market">
          <Button variant="outline" size="sm" className="bg-space-blue hover:bg-space-blue/80 border-neon-blue/20">
            <TrendingUp className="mr-2 h-4 w-4" /> View Market
          </Button>
        </Link>
      </div>
      
      {/* Coin Overview */}
      <div className="glassmorphism rounded-xl p-6 mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="h-12 w-12 rounded-full mr-3 flex items-center justify-center">
              <img src={coin.image.small} alt={coin.name} className="h-full w-full" />
            </div>
            <div>
              <h2 className="text-2xl font-orbitron font-bold text-stellar-white">{coin.name}</h2>
              <p className="text-stellar-gray">{coin.symbol.toUpperCase()}</p>
            </div>
          </div>
          <div className="flex items-center">
            <a 
              href={coin.links.homepage[0]} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center mr-4 px-3 py-2 rounded-lg bg-space-blue hover:bg-space-blue/80 text-sm border border-neon-blue/20"
            >
              <ExternalLink className="h-4 w-4 mr-2" /> Website
            </a>
            <Button
              variant={isInWatchlist ? "default" : "outline"}
              size="icon"
              onClick={handleWatchlist}
              className={isInWatchlist ? "bg-neon-yellow text-space-darkBlue hover:bg-neon-yellow/90" : "border-neon-yellow text-neon-yellow hover:bg-neon-yellow/20"}
            >
              <Star className="h-5 w-5" fill={isInWatchlist ? "currentColor" : "none"} />
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="p-4 rounded-lg bg-space-blue/30">
            <p className="text-stellar-gray text-sm mb-1">Current Price</p>
            <p className="text-2xl font-bold">{formatCurrency(coin.market_data.current_price.usd)}</p>
            <p className={`text-sm mt-1 ${coin.market_data.price_change_percentage_24h >= 0 ? 'text-neon-green' : 'text-neon-red'}`}>
              {formatPercentage(coin.market_data.price_change_percentage_24h)} (24h)
            </p>
          </div>
          
          <div className="p-4 rounded-lg bg-space-blue/30">
            <p className="text-stellar-gray text-sm mb-1">Market Cap</p>
            <p className="text-2xl font-bold">{formatCurrency(coin.market_data.market_cap.usd, "USD", true)}</p>
            <p className="text-sm mt-1 text-stellar-gray">Rank #{coin.market_cap_rank}</p>
          </div>
          
          <div className="p-4 rounded-lg bg-space-blue/30">
            <p className="text-stellar-gray text-sm mb-1">Trading Volume (24h)</p>
            <p className="text-2xl font-bold">{formatCurrency(coin.market_data.total_volume.usd, "USD", true)}</p>
            <p className="text-sm mt-1 text-stellar-gray">
              {(coin.market_data.total_volume.usd / coin.market_data.market_cap.usd * 100).toFixed(2)}% of market cap
            </p>
          </div>
        </div>
        
        {/* Price Chart */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-orbitron font-semibold">Price Chart</h3>
            <div className="flex space-x-2">
              <Button 
                variant={chartPeriod === 1 ? "default" : "outline"} 
                size="sm"
                onClick={() => setChartPeriod(1)}
                className={chartPeriod === 1 ? "bg-neon-blue text-space-darkBlue" : "bg-space-blue border-neon-blue/20"}
              >
                24h
              </Button>
              <Button 
                variant={chartPeriod === 7 ? "default" : "outline"} 
                size="sm"
                onClick={() => setChartPeriod(7)}
                className={chartPeriod === 7 ? "bg-neon-blue text-space-darkBlue" : "bg-space-blue border-neon-blue/20"}
              >
                7d
              </Button>
              <Button 
                variant={chartPeriod === 30 ? "default" : "outline"} 
                size="sm"
                onClick={() => setChartPeriod(30)}
                className={chartPeriod === 30 ? "bg-neon-blue text-space-darkBlue" : "bg-space-blue border-neon-blue/20"}
              >
                30d
              </Button>
              <Button 
                variant={chartPeriod === 90 ? "default" : "outline"} 
                size="sm"
                onClick={() => setChartPeriod(90)}
                className={chartPeriod === 90 ? "bg-neon-blue text-space-darkBlue" : "bg-space-blue border-neon-blue/20"}
              >
                90d
              </Button>
            </div>
          </div>
          
          {chartData && (
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={chartData}
                  margin={{
                    top: 10,
                    right: 0,
                    left: 0,
                    bottom: 0,
                  }}
                >
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00E5FF" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#00E5FF" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#ADB5BD" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => {
                      if (chartPeriod === 1) {
                        // For 24h, show hours
                        const hour = new Date(value).getHours();
                        return `${hour}:00`;
                      }
                      return value;
                    }}
                  />
                  <YAxis 
                    stroke="#ADB5BD" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    domain={['auto', 'auto']}
                    tickFormatter={(value) => `$${value.toLocaleString()}`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "rgba(28, 37, 65, 0.9)",
                      borderColor: "rgba(0, 229, 255, 0.2)",
                      borderRadius: "8px",
                      fontSize: "12px",
                      color: "#F8F9FA"
                    }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, "Price"]}
                    labelFormatter={(label) => `Date: ${label}`}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#00E5FF" 
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorPrice)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
      
      {/* Detailed Info Tabs */}
      <div className="glassmorphism rounded-xl p-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="overview" className="font-orbitron">
              <Sparkles className="mr-2 h-4 w-4" /> Overview
            </TabsTrigger>
            <TabsTrigger value="ai-prediction" className="font-orbitron">
              <Brain className="mr-2 h-4 w-4" /> AI Prediction
            </TabsTrigger>
            <TabsTrigger value="whale-alerts" className="font-orbitron">
              <Waves className="mr-2 h-4 w-4" /> Whale Alerts
            </TabsTrigger>
          </TabsList>
          
          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Description */}
            <div>
              <h3 className="text-lg font-semibold mb-4">About {coin.name}</h3>
              <div className="text-stellar-gray space-y-4 max-h-40 overflow-y-auto pr-2">
                {coin.description.en ? (
                  <div dangerouslySetInnerHTML={{ __html: coin.description.en.split('. ').slice(0, 5).join('. ') + '.' }} />
                ) : (
                  <p>No description available.</p>
                )}
              </div>
            </div>
            
            {/* Market Stats */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Market Stats</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-space-blue/30 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">All-Time High</span>
                    <span className="font-medium">{formatCurrency(coin.market_data.ath.usd)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">All-Time Low</span>
                    <span className="font-medium">{formatCurrency(coin.market_data.atl.usd)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">Price Change (7d)</span>
                    <span className={`font-medium ${coin.market_data.price_change_percentage_7d >= 0 ? 'text-neon-green' : 'text-neon-red'}`}>
                      {formatPercentage(coin.market_data.price_change_percentage_7d)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">Price Change (30d)</span>
                    <span className={`font-medium ${coin.market_data.price_change_percentage_30d >= 0 ? 'text-neon-green' : 'text-neon-red'}`}>
                      {formatPercentage(coin.market_data.price_change_percentage_30d)}
                    </span>
                  </div>
                </div>
                
                <div className="p-4 rounded-lg bg-space-blue/30 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">Circulating Supply</span>
                    <span className="font-medium">{coin.market_data.circulating_supply.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">Total Supply</span>
                    <span className="font-medium">{coin.market_data.total_supply ? coin.market_data.total_supply.toLocaleString() : "∞"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">Max Supply</span>
                    <span className="font-medium">{coin.market_data.max_supply ? coin.market_data.max_supply.toLocaleString() : "∞"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stellar-gray">Market Cap Change (24h)</span>
                    <span className={`font-medium ${coin.market_data.market_cap_change_percentage_24h >= 0 ? 'text-neon-green' : 'text-neon-red'}`}>
                      {formatPercentage(coin.market_data.market_cap_change_percentage_24h)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Social Stats */}
            {(coin.community_data || coin.developer_data) && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Community & Development</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {coin.community_data && (
                    <div className="p-4 rounded-lg bg-space-blue/30 space-y-2">
                      <h4 className="font-medium mb-2">Community Stats</h4>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Twitter Followers</span>
                        <span className="font-medium">{coin.community_data.twitter_followers?.toLocaleString() || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Reddit Subscribers</span>
                        <span className="font-medium">{coin.community_data.reddit_subscribers?.toLocaleString() || "N/A"}</span>
                      </div>
                    </div>
                  )}
                  
                  {coin.developer_data && (
                    <div className="p-4 rounded-lg bg-space-blue/30 space-y-2">
                      <h4 className="font-medium mb-2">Development Stats</h4>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">GitHub Stars</span>
                        <span className="font-medium">{coin.developer_data.stars?.toLocaleString() || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Forks</span>
                        <span className="font-medium">{coin.developer_data.forks?.toLocaleString() || "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Commits (4 weeks)</span>
                        <span className="font-medium">{coin.developer_data.commit_count_4_weeks?.toLocaleString() || "N/A"}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </TabsContent>
          
          {/* AI Prediction Tab */}
          <TabsContent value="ai-prediction">
            {!predictionAvailable ? (
              <div className="text-center p-8">
                <Brain className="h-12 w-12 mx-auto text-neon-blue mb-3" />
                <h3 className="text-xl font-semibold mb-2">No AI Prediction Available</h3>
                <p className="text-stellar-gray mb-6">
                  Our AI hasn't generated a prediction for this coin yet. Check back later for insights.
                </p>
              </div>
            ) : !canAccessPrediction ? (
              <div className="text-center p-8 relative glassmorphism rounded-xl">
                <div className="absolute inset-0 flex items-center justify-center z-10 bg-space-darkBlue/50 backdrop-blur-sm rounded-xl">
                  <div className="text-center p-6">
                    <div className="w-16 h-16 rounded-full bg-neon-pink/20 flex items-center justify-center mx-auto mb-4">
                      <Lock className="h-8 w-8 text-neon-pink" />
                    </div>
                    <h4 className="text-xl font-orbitron font-bold mb-2">Premium Content</h4>
                    <p className="text-sm text-stellar-gray mb-4">
                      Upgrade to {prediction.requiredTier} or higher to unlock advanced AI predictions and analysis.
                    </p>
                    <Link href="/subscription">
                      <Button className="bg-neon-pink text-space-darkBlue hover:bg-neon-pink/90 font-medium">
                        Upgrade Now
                      </Button>
                    </Link>
                  </div>
                </div>
                
                <div className="blur-sm">
                  <Brain className="h-12 w-12 mx-auto text-neon-blue mb-3" />
                  <h3 className="text-xl font-semibold mb-6">AI Analysis & Prediction</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div className="p-5 rounded-lg bg-space-blue/30">
                      <h4 className="font-medium mb-4 flex items-center">
                        <Sparkles className="mr-2 h-4 w-4 text-neon-blue" /> Signal Information
                      </h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Signal</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Confidence</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Risk Level</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Accuracy Score</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-5 rounded-lg bg-space-blue/30">
                      <h4 className="font-medium mb-4 flex items-center">
                        <BarChart4 className="mr-2 h-4 w-4 text-neon-blue" /> Price Targets
                      </h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Short-term Target</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Long-term Target</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-stellar-gray">Stop Loss</span>
                          <span className="font-medium">•••••••</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-5 rounded-lg bg-space-blue/30 mb-6">
                    <h4 className="font-medium mb-4">AI Analysis</h4>
                    <p className="text-stellar-gray leading-relaxed">
                      ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• 
                      ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• •••••••
                      ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• ••••••• •••••••
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center mb-6">
                  <Brain className="h-6 w-6 text-neon-blue mr-2" />
                  <h3 className="text-xl font-semibold">AI Analysis & Prediction</h3>
                  <div className="ml-auto flex items-center">
                    <div className="px-2 py-1 text-xs rounded-full bg-neon-blue/20 text-neon-blue font-medium">
                      {prediction.accuracy}% Accuracy
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="p-5 rounded-lg bg-space-blue/30">
                    <h4 className="font-medium mb-4 flex items-center">
                      <Sparkles className="mr-2 h-4 w-4 text-neon-blue" /> Signal Information
                    </h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Signal</span>
                        <span className={`font-medium ${getSignalColor(prediction.signal)}`}>
                          {prediction.signal}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Confidence</span>
                        <span className="font-medium">{prediction.confidence}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Risk Level</span>
                        <span className={`font-medium ${getRiskColor(prediction.riskLevel)}`}>
                          {prediction.riskLevel}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Last Updated</span>
                        <span className="font-medium">
                          {new Date(prediction.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-5 rounded-lg bg-space-blue/30">
                    <h4 className="font-medium mb-4 flex items-center">
                      <BarChart4 className="mr-2 h-4 w-4 text-neon-blue" /> Price Targets
                    </h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Short-term Target</span>
                        <span className="font-medium text-neon-green">{prediction.shortTermPrice}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Long-term Target</span>
                        <span className="font-medium text-neon-green">{prediction.longTermPrice}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stellar-gray">Stop Loss</span>
                        <span className="font-medium text-neon-red">{prediction.stopLoss}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="p-5 rounded-lg bg-space-blue/30 mb-6">
                  <h4 className="font-medium mb-4">AI Analysis</h4>
                  <p className="text-stellar-gray leading-relaxed">
                    {prediction.analysis}
                  </p>
                </div>
                
                <div className="text-sm text-stellar-gray">
                  <div className="flex items-center">
                    <Info className="h-4 w-4 mr-2 text-neon-blue" />
                    <p>AI predictions are based on historical data, market trends, and sentiment analysis. They should not be considered as financial advice.</p>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
          
          {/* Whale Alerts Tab */}
          <TabsContent value="whale-alerts">
            {whaleAlertsLoading ? (
              <div className="p-4">
                <Skeleton className="h-64 w-full" />
              </div>
            ) : !whaleAlerts || whaleAlerts.length === 0 ? (
              <div className="text-center p-8">
                <Waves className="h-12 w-12 mx-auto text-neon-blue mb-3" />
                <h3 className="text-xl font-semibold mb-2">No Whale Activity Found</h3>
                <p className="text-stellar-gray mb-6">
                  There haven't been any large transactions detected for this coin recently.
                </p>
              </div>
            ) : (
              <div>
                <div className="flex items-center mb-6">
                  <Waves className="h-6 w-6 text-neon-blue mr-2" />
                  <h3 className="text-xl font-semibold">Recent Whale Activity</h3>
                </div>
                
                <div className="space-y-4">
                  {whaleAlerts.map((alert) => {
                    const canAccess = canAccessTier(userTier, alert.requiredTier);
                    
                    return (
                      <div key={alert.id} className="p-4 rounded-lg bg-space-blue/30 relative">
                        {!canAccess && (
                          <div className="absolute inset-0 flex items-center justify-center z-10 bg-space-darkBlue/50 backdrop-blur-sm rounded-lg">
                            <div className="text-center p-4">
                              <Lock className="h-6 w-6 text-neon-pink mx-auto mb-2" />
                              <p className="text-sm">
                                <Link href="/subscription" className="text-neon-pink hover:underline">
                                  Upgrade to {alert.requiredTier}
                                </Link> to view this alert
                              </p>
                            </div>
                          </div>
                        )}
                        
                        <div className={!canAccess ? "blur-sm" : ""}>
                          <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
                            <div className="mb-2 md:mb-0">
                              <span className="text-sm text-stellar-gray">
                                {new Date(alert.timestamp).toLocaleString()}
                              </span>
                              {alert.transactionType && (
                                <span className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                                  alert.transactionType === "Exchange Withdrawal" 
                                    ? "bg-neon-yellow/20 text-neon-yellow" 
                                    : "bg-neon-green/20 text-neon-green"
                                }`}>
                                  {alert.transactionType}
                                </span>
                              )}
                            </div>
                            <div className="text-lg font-bold">{alert.amountUsd}</div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                            <div>
                              <span className="text-stellar-gray">From: </span>
                              <span className="text-neon-blue">{alert.fromAddress.substring(0, 8)}...{alert.fromAddress.substring(alert.fromAddress.length - 8)}</span>
                              {alert.fromLabel && (
                                <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-neon-blue/10 text-neon-blue">
                                  {alert.fromLabel}
                                </span>
                              )}
                            </div>
                            <div>
                              <span className="text-stellar-gray">To: </span>
                              <span className="text-neon-blue">{alert.toAddress.substring(0, 8)}...{alert.toAddress.substring(alert.toAddress.length - 8)}</span>
                              {alert.toLabel && (
                                <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-neon-blue/10 text-neon-blue">
                                  {alert.toLabel}
                                </span>
                              )}
                            </div>
                          </div>
                          
                          <div className="mt-2 text-sm">
                            <span className="text-stellar-gray">Amount: </span>
                            <span>{alert.amount} {alert.token}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                <div className="mt-6">
                  <Link href="/whale-alerts">
                    <Button variant="outline" className="w-full bg-space-blue hover:bg-space-blue/80 border-neon-blue/20">
                      View All Whale Alerts
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
