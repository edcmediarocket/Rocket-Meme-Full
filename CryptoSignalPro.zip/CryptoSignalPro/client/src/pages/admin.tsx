import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchAllUsers, updateUserSubscription } from "@/lib/api";
import { User } from "@/types";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Users, Shield, Calendar } from "lucide-react";

export default function Admin() {
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: users, isLoading } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: fetchAllUsers,
  });

  const handleUpdateSubscription = async (userId: number, newTier: string) => {
    try {
      await updateUserSubscription(userId, newTier);
      toast({
        title: "Subscription updated",
        description: `User's subscription has been updated to ${newTier}.`,
      });
      
      // Refresh the user list
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update user subscription tier.",
        variant: "destructive",
      });
    }
  };

  // Filter users based on search query
  const filteredUsers = users?.filter(user => 
    user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.displayName?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Admin Dashboard</h2>
        <p className="text-stellar-gray text-sm">Manage users and subscriptions</p>
      </div>

      {/* Admin Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="glassmorphism rounded-xl p-4 flex items-center">
          <div className="h-12 w-12 rounded-full bg-neon-blue/20 flex items-center justify-center mr-4">
            <Users className="h-6 w-6 text-neon-blue" />
          </div>
          <div>
            <p className="text-stellar-gray text-sm">Total Users</p>
            <p className="text-2xl font-bold">{isLoading ? "..." : users?.length || 0}</p>
          </div>
        </div>
        
        <div className="glassmorphism rounded-xl p-4 flex items-center">
          <div className="h-12 w-12 rounded-full bg-neon-pink/20 flex items-center justify-center mr-4">
            <Shield className="h-6 w-6 text-neon-pink" />
          </div>
          <div>
            <p className="text-stellar-gray text-sm">Premium Users</p>
            <p className="text-2xl font-bold">
              {isLoading ? "..." : users?.filter(user => user.subscriptionTier === "Premium").length || 0}
            </p>
          </div>
        </div>
        
        <div className="glassmorphism rounded-xl p-4 flex items-center">
          <div className="h-12 w-12 rounded-full bg-neon-green/20 flex items-center justify-center mr-4">
            <Calendar className="h-6 w-6 text-neon-green" />
          </div>
          <div>
            <p className="text-stellar-gray text-sm">Active Today</p>
            <p className="text-2xl font-bold">
              {isLoading ? "..." : users?.filter(user => {
                if (!user.lastLogin) return false;
                const today = new Date();
                const lastLogin = new Date(user.lastLogin);
                return today.toDateString() === lastLogin.toDateString();
              }).length || 0}
            </p>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6 relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-stellar-gray" />
        <Input
          type="text"
          placeholder="Search users by username or email..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-space-midnight border-neon-blue/20 w-full md:w-1/2"
        />
      </div>

      {/* Users Table */}
      <div className="glassmorphism rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="p-6">
            <Skeleton className="h-8 w-full mb-4" />
            <Skeleton className="h-72 w-full" />
          </div>
        ) : !filteredUsers || filteredUsers.length === 0 ? (
          <div className="p-8 text-center">
            <Users className="h-12 w-12 mx-auto text-neon-blue mb-3" />
            <h3 className="text-xl font-semibold mb-2">No users found</h3>
            <p className="text-stellar-gray">
              {searchQuery ? "No users match your search criteria." : "There are no users in the system."}
            </p>
          </div>
        ) : (
          <Table>
            <TableCaption>List of all registered users</TableCaption>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-stellar-gray">Username</TableHead>
                <TableHead className="text-stellar-gray">Email</TableHead>
                <TableHead className="text-stellar-gray">Display Name</TableHead>
                <TableHead className="text-stellar-gray">Subscription Tier</TableHead>
                <TableHead className="text-stellar-gray">Last Login</TableHead>
                <TableHead className="text-stellar-gray">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id} className="hover:bg-space-blue/30">
                  <TableCell className="font-medium">{user.username}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.displayName || "-"}</TableCell>
                  <TableCell>
                    <Select
                      defaultValue={user.subscriptionTier}
                      onValueChange={(value) => handleUpdateSubscription(user.id, value)}
                    >
                      <SelectTrigger className="w-32 bg-space-blue border-neon-blue/20">
                        <SelectValue placeholder={user.subscriptionTier} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Basic">Basic</SelectItem>
                        <SelectItem value="Pro">Pro</SelectItem>
                        <SelectItem value="Premium">Premium</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-stellar-gray">
                    {user.lastLogin ? new Date(user.lastLogin).toLocaleString() : "Never"}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-space-blue hover:bg-space-blue/80 border-neon-blue/20"
                    >
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
}
