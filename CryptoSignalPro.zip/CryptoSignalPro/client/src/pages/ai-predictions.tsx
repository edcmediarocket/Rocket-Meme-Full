import { useQuery } from "@tanstack/react-query";
import { fetchPredictions, fetchUserSubscription } from "@/lib/api";
import { User, AIPrediction } from "@/types";
import { Brain, Lock, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { canAccessTier, getSignalColor, getRiskColor } from "@/lib/utils";
import { useState } from "react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function AIPredictions() {
  const [activeFilter, setActiveFilter] = useState("all");

  const { data: predictions, isLoading: predictionsLoading } = useQuery({
    queryKey: ['/api/predictions'],
    queryFn: fetchPredictions,
  });

  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });

  const isLoading = predictionsLoading || subscriptionLoading;
  const userTier = subscription?.tier || "Basic";

  // Filter predictions based on the active filter
  const filteredPredictions = !predictions ? [] : 
    activeFilter === "all" ? predictions :
    activeFilter === "buy" ? predictions.filter(p => p.signal.toLowerCase().includes("buy")) :
    activeFilter === "sell" ? predictions.filter(p => p.signal.toLowerCase().includes("sell")) :
    activeFilter === "hold" ? predictions.filter(p => p.signal.toLowerCase() === "hold") : 
    predictions;

  if (isLoading) {
    return (
      <div>
        <div className="mb-8">
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">AI Predictions</h2>
          <p className="text-stellar-gray text-sm">Advanced market predictions powered by AI</p>
        </div>

        <div className="glassmorphism rounded-xl p-6 mb-6">
          <Skeleton className="h-10 w-full mb-4" />
          <Skeleton className="h-24 w-full" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, index) => (
            <div key={index} className="glassmorphism rounded-xl p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded-full mr-2" />
                  <div>
                    <Skeleton className="h-5 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
              </div>
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-32 w-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8 flex flex-col lg:flex-row lg:items-center justify-between">
        <div>
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">AI Predictions</h2>
          <p className="text-stellar-gray text-sm">Advanced market predictions powered by AI</p>
        </div>
      </div>

      {/* Explanation Card */}
      <div className="glassmorphism rounded-xl p-6 mb-6 border border-neon-blue/30">
        <div className="flex items-start">
          <Brain className="h-8 w-8 text-neon-pink mr-3 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-orbitron font-semibold mb-2">About AI Predictions</h3>
            <p className="text-stellar-gray text-sm mb-4">
              Our advanced AI model analyzes market trends, on-chain activity, and sentiment to generate buy/sell signals with confidence scores.
              Predictions include price targets, stop-loss levels, and risk assessment to help you make informed trading decisions.
            </p>
            <div className="flex flex-wrap gap-3 text-xs">
              <div className="flex items-center px-2 py-1 rounded-full bg-neon-green/20 text-neon-green">
                <span className="font-medium">Buy Signal</span>
              </div>
              <div className="flex items-center px-2 py-1 rounded-full bg-neon-red/20 text-neon-red">
                <span className="font-medium">Sell Signal</span>
              </div>
              <div className="flex items-center px-2 py-1 rounded-full bg-neon-yellow/20 text-neon-yellow">
                <span className="font-medium">Hold Signal</span>
              </div>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center px-2 py-1 rounded-full bg-neon-blue/20 text-neon-blue cursor-help">
                      <Info className="h-3 w-3 mr-1" />
                      <span className="font-medium">Accuracy Score</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="bg-space-blue border-neon-blue/30 text-stellar-white">
                    <p>Percentage of previous predictions that were correct</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-6">
        <Tabs defaultValue="all" value={activeFilter} onValueChange={setActiveFilter} className="w-full">
          <TabsList className="grid grid-cols-4 glassmorphism">
            <TabsTrigger value="all">All Predictions</TabsTrigger>
            <TabsTrigger value="buy">Buy Signals</TabsTrigger>
            <TabsTrigger value="sell">Sell Signals</TabsTrigger>
            <TabsTrigger value="hold">Hold Signals</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Predictions Grid */}
      {filteredPredictions.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPredictions.map((prediction) => (
            <PredictionCard 
              key={prediction.id}
              prediction={prediction}
              userTier={userTier}
            />
          ))}
        </div>
      ) : (
        <div className="glassmorphism rounded-xl p-8 text-center">
          <Brain className="h-12 w-12 mx-auto text-neon-blue mb-3" />
          <h3 className="text-xl font-semibold mb-2">No predictions found</h3>
          <p className="text-stellar-gray">
            {activeFilter === "all"
              ? "No AI predictions available at the moment. Check back later."
              : `No ${activeFilter} signals available at the moment. Try a different filter.`}
          </p>
        </div>
      )}
    </div>
  );
}

interface PredictionCardProps {
  prediction: AIPrediction;
  userTier: string;
}

function PredictionCard({ prediction, userTier }: PredictionCardProps) {
  const canAccess = canAccessTier(userTier, prediction.requiredTier);
  
  return (
    <div className="glassmorphism rounded-xl overflow-hidden relative">
      {!canAccess && (
        <div className="absolute inset-0 flex items-center justify-center z-10 bg-space-darkBlue/50 backdrop-blur-sm">
          <div className="text-center p-6">
            <div className="w-16 h-16 rounded-full bg-neon-pink/20 flex items-center justify-center mx-auto mb-4">
              <Lock className="h-8 w-8 text-neon-pink" />
            </div>
            <h4 className="text-xl font-orbitron font-bold mb-2">Premium Content</h4>
            <p className="text-sm text-stellar-gray mb-4">
              Upgrade to {prediction.requiredTier} or higher to unlock advanced AI predictions and analysis.
            </p>
            <Link href="/subscription">
              <Button className="bg-neon-pink text-space-darkBlue hover:bg-neon-pink/90 font-medium">
                Upgrade Now
              </Button>
            </Link>
          </div>
        </div>
      )}
      
      <div className={!canAccess ? "premium-content" : ""}>
        <div className="flex justify-between items-start p-4 border-b border-neon-blue/20">
          <div className="flex items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
              prediction.coinId === "bitcoin" ? "bg-[#F7931A]" : 
              prediction.coinId === "ethereum" ? "bg-[#627EEA]" :
              prediction.coinId === "dogecoin" ? "bg-[#C3A634]" :
              "bg-[#E42D04]"
            }`}>
              {prediction.coinId === "bitcoin" ? "₿" : 
               prediction.coinId === "ethereum" ? "Ξ" : 
               prediction.coinId === "dogecoin" ? "Ð" : "🐕"}
            </div>
            <div>
              <h4 className="font-bold capitalize">{prediction.coinId.replace(/-/g, ' ')}</h4>
              <p className="text-xs text-stellar-gray">AI Prediction</p>
            </div>
          </div>
          <div className="flex items-center">
            <div className="px-2 py-1 text-xs rounded-full bg-neon-blue/20 text-neon-blue font-medium">
              {prediction.accuracy}% Accuracy
            </div>
          </div>
        </div>
        
        <div className="p-4">
          <div className="mb-4">
            <div className="flex justify-between mb-1">
              <span className="text-sm">AI Signal:</span>
              <span className={`text-sm font-medium ${getSignalColor(prediction.signal)}`}>
                {prediction.signal}
              </span>
            </div>
            <div className="flex justify-between mb-1">
              <span className="text-sm">Confidence:</span>
              <span className="text-sm font-medium">{prediction.confidence}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Risk Level:</span>
              <span className={`text-sm font-medium ${getRiskColor(prediction.riskLevel)}`}>
                {prediction.riskLevel}
              </span>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between mb-1">
              <span className="text-sm">Short-term Target:</span>
              <span className="text-sm font-medium text-neon-green">
                {prediction.shortTermPrice}
              </span>
            </div>
            <div className="flex justify-between mb-1">
              <span className="text-sm">Long-term Target:</span>
              <span className="text-sm font-medium text-neon-green">
                {prediction.longTermPrice}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm">Stop Loss:</span>
              <span className="text-sm font-medium text-neon-red">
                {prediction.stopLoss}
              </span>
            </div>
          </div>
          
          <div className="mt-4">
            <h5 className="text-sm font-semibold mb-2">AI Analysis:</h5>
            <p className="text-sm text-stellar-gray">{prediction.analysis}</p>
          </div>
          
          <div className="mt-4 flex justify-end">
            <Link href={`/coin/${prediction.coinId}`}>
              <Button variant="outline" className="px-3 py-1.5 text-sm rounded-lg bg-neon-blue/20 text-neon-blue hover:bg-neon-blue/30 border-none">
                View Coin Details
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
