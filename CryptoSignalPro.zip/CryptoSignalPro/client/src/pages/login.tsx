import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { signInWithGoogle, signInWithEmail, signUpWithEmail } from "@/lib/firebase";
import { toast } from "@/hooks/use-toast";
import RocketAnimation from "@/components/common/RocketAnimation";
import StarsBackground from "@/components/common/StarsBackground";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { FaGoogle } from "react-icons/fa";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

// Form validation schemas
const loginSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
});

const registerSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const [_, navigate] = useLocation();
  const [isFirebaseAvailable, setIsFirebaseAvailable] = useState(true);

  // Check if Firebase is available
  useEffect(() => {
    const hasFirebaseKeys = 
      import.meta.env.VITE_FIREBASE_API_KEY && 
      import.meta.env.VITE_FIREBASE_PROJECT_ID && 
      import.meta.env.VITE_FIREBASE_APP_ID;
    
    setIsFirebaseAvailable(Boolean(hasFirebaseKeys));
  }, []);

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      username: "",
    },
  });

  const handleLoginWithEmail = async (data: LoginFormValues) => {
    try {
      setIsLoading(true);
      const result = await signInWithEmail(data.email, data.password);
      toast({
        title: "Login successful!",
        description: "Welcome to Rocket Meme",
      });
      navigate("/dashboard");
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "There was an error logging in",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (data: RegisterFormValues) => {
    try {
      setIsLoading(true);
      await signUpWithEmail(data.email, data.password);
      toast({
        title: "Registration successful!",
        description: "Your account has been created. Welcome to Rocket Meme!",
      });
      navigate("/dashboard");
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error.message || "There was an error creating your account",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setIsLoading(true);
      await signInWithGoogle();
      toast({
        title: "Login successful!",
        description: "Welcome to Rocket Meme",
      });
      navigate("/dashboard");
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "There was an error logging in with Google",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center px-4">
      <StarsBackground />
      
      <div className="flex flex-col items-center mb-8">
        <div className="flex items-center mb-4">
          <RocketAnimation size="sm" className="mr-2" />
          <h1 className="font-orbitron text-4xl font-bold bg-gradient-to-r from-neon-blue to-neon-pink text-transparent bg-clip-text">
            Rocket Meme
          </h1>
        </div>
        <p className="text-stellar-gray text-center max-w-md">
          Your ultimate crypto signals and AI predictions platform for meme coins and beyond
        </p>
      </div>
      
      <Card className="w-full max-w-md glassmorphism">
        <CardHeader>
          <CardTitle className="text-center font-orbitron">Welcome</CardTitle>
          <CardDescription className="text-center">Sign in to access AI predictions and whale alerts</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(handleLoginWithEmail)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="your@email.com" 
                            {...field} 
                            className="bg-space-midnight border-neon-blue/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="••••••••" 
                            {...field}
                            className="bg-space-midnight border-neon-blue/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90"
                    disabled={isLoading}
                  >
                    {isLoading ? "Logging in..." : "Login"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
            
            <TabsContent value="register">
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="cooluser123" 
                            {...field}
                            className="bg-space-midnight border-neon-blue/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="your@email.com" 
                            {...field}
                            className="bg-space-midnight border-neon-blue/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="••••••••" 
                            {...field}
                            className="bg-space-midnight border-neon-blue/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-neon-pink text-space-darkBlue hover:bg-neon-pink/90"
                    disabled={isLoading}
                  >
                    {isLoading ? "Creating account..." : "Create Account"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
          
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-neon-blue/20"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-space-darkBlue px-2 text-stellar-gray">Or continue with</span>
            </div>
          </div>
          
          {!isFirebaseAvailable && (
            <Alert className="mb-4 bg-space-blue/30 border-yellow-600/30">
              <AlertCircle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-xs">
                Google login is currently unavailable. Please use email/password login instead.
              </AlertDescription>
            </Alert>
          )}
          
          <Button 
            variant="outline" 
            className="w-full bg-space-blue hover:bg-space-blue/80 border-neon-blue/20 flex items-center justify-center"
            onClick={handleGoogleLogin}
            disabled={isLoading || !isFirebaseAvailable}
          >
            <FaGoogle className="mr-2" />
            Google
          </Button>
        </CardContent>
        <CardFooter className="flex flex-col">
          <p className="text-xs text-stellar-gray text-center">
            By signing up, you agree to our Terms of Service and Privacy Policy. 
            Your data will be stored securely.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
