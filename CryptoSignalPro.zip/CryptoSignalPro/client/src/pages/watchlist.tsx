import { useQuery } from "@tanstack/react-query";
import { fetchWatchlist, removeFromWatchlist } from "@/lib/api";
import { Star, Trash2, Info, Eye } from "lucide-react";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Coin } from "@/types";
import { useState } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function Watchlist() {
  const { data: watchlist, isLoading } = useQuery({
    queryKey: ['/api/user/watchlist'],
    queryFn: fetchWatchlist,
  });
  
  const [coinToRemove, setCoinToRemove] = useState<Coin | null>(null);

  const handleRemoveFromWatchlist = async (coin: Coin) => {
    try {
      await removeFromWatchlist(coin.id);
      toast({
        title: "Removed from watchlist",
        description: `${coin.name} has been removed from your watchlist.`,
      });
      
      // Invalidate watchlist query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/user/watchlist'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error updating your watchlist.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div>
        <div className="mb-8">
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">My Watchlist</h2>
          <p className="text-stellar-gray text-sm">Track your favorite cryptocurrencies</p>
        </div>
        
        <div className="glassmorphism rounded-xl p-6 mb-6">
          <Skeleton className="h-32 w-full" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, index) => (
            <div key={index} className="glassmorphism rounded-xl p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded-full mr-2" />
                  <div>
                    <Skeleton className="h-5 w-24 mb-1" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
                <Skeleton className="h-8 w-8 rounded" />
              </div>
              <Skeleton className="h-7 w-32 mb-3" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-8 w-full mt-4" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8 flex flex-col lg:flex-row lg:items-center justify-between">
        <div>
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">My Watchlist</h2>
          <p className="text-stellar-gray text-sm">Track your favorite cryptocurrencies</p>
        </div>
      </div>

      {/* Explanation Card */}
      <div className="glassmorphism rounded-xl p-6 mb-6 border border-neon-blue/30">
        <div className="flex items-start">
          <Star className="h-8 w-8 text-neon-yellow mr-3 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-orbitron font-semibold mb-2">About Watchlist</h3>
            <p className="text-stellar-gray text-sm mb-4">
              Add your favorite cryptocurrencies to your watchlist to easily track their performance.
              Click the star icon on any coin to add it to your watchlist. From here, you can quickly access
              detailed information and remove coins you no longer wish to track.
            </p>
            <div className="flex flex-wrap gap-3 text-xs">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center px-2 py-1 rounded-full bg-neon-blue/20 text-neon-blue cursor-help">
                      <Info className="h-3 w-3 mr-1" />
                      <span className="font-medium">Pro Tip</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="bg-space-blue border-neon-blue/30 text-stellar-white">
                    <p>Upgrade to Pro or Premium to set price alerts for your watchlist coins</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </div>

      {/* Watchlist Grid */}
      {!watchlist || watchlist.length === 0 ? (
        <div className="glassmorphism rounded-xl p-8 text-center">
          <Star className="h-12 w-12 mx-auto text-neon-blue mb-3" />
          <h3 className="text-xl font-semibold mb-2">Your watchlist is empty</h3>
          <p className="text-stellar-gray mb-6">
            You haven't added any cryptocurrencies to your watchlist yet. Browse the market and star your favorites.
          </p>
          <Link href="/market">
            <Button className="bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90">
              Browse Market
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {watchlist.map((coin) => (
            <div key={coin.id} className="glassmorphism rounded-xl p-4 neon-border">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                    coin.id === "bitcoin" ? "bg-[#F7931A]" : 
                    coin.id === "ethereum" ? "bg-[#627EEA]" :
                    coin.id === "dogecoin" ? "bg-[#C3A634]" :
                    coin.id === "shiba-inu" ? "bg-[#E42D04]" :
                    "bg-gray-500"
                  }`}>
                    {coin.id === "bitcoin" ? "₿" : 
                     coin.id === "ethereum" ? "Ξ" : 
                     coin.id === "dogecoin" ? "Ð" : 
                     coin.id === "shiba-inu" ? "🐕" : 
                     coin.symbol.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="font-bold">{coin.name}</h4>
                    <p className="text-xs text-stellar-gray">{coin.symbol.toUpperCase()}</p>
                  </div>
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      className="h-8 w-8 rounded-full hover:bg-neon-red/10 text-neon-red"
                      onClick={() => setCoinToRemove(coin)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="glassmorphism border-neon-red/30">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove from Watchlist</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to remove {coin.name} from your watchlist?
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-space-blue hover:bg-space-blue/80">Cancel</AlertDialogCancel>
                      <AlertDialogAction 
                        className="bg-neon-red text-white hover:bg-neon-red/90"
                        onClick={() => handleRemoveFromWatchlist(coin)}
                      >
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
              
              <div className="text-2xl font-bold mb-3">
                {formatCurrency(coin.current_price)}
              </div>
              
              <div className="flex items-center justify-between mb-4">
                <div className={`flex items-center ${coin.price_change_percentage_24h >= 0 ? 'text-neon-green' : 'text-neon-red'}`}>
                  <span className="material-icons text-sm mr-1">
                    {coin.price_change_percentage_24h >= 0 ? 'arrow_upward' : 'arrow_downward'}
                  </span>
                  <span className="text-sm">{formatPercentage(coin.price_change_percentage_24h)}</span>
                </div>
                <div className="text-xs text-stellar-gray">
                  24h Volume: {formatCurrency(coin.total_volume, "USD", true)}
                </div>
              </div>
              
              <Link href={`/coin/${coin.id}`}>
                <Button variant="outline" className="w-full bg-neon-blue/10 text-neon-blue hover:bg-neon-blue/20 border-none">
                  <Eye className="h-4 w-4 mr-2" /> View Details
                </Button>
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
