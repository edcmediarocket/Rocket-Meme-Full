import { useQuery } from "@tanstack/react-query";
import { fetchWhaleAlerts, fetchUserSubscription } from "@/lib/api";
import { useState } from "react";
import { 
  Waves, 
  Filter, 
  ChevronLeft, 
  ChevronRight, 
  Info,
  ExternalLink,
  Search
} from "lucide-react";
import { 
  formatCurrency, 
  shortenAddress, 
  formatTimeAgo,
  canAccessTier
} from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { WhaleAlert } from "@/types";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Link } from "wouter";

export default function WhaleAlerts() {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [tokenFilter, setTokenFilter] = useState("all");
  const [transactionTypeFilter, setTransactionTypeFilter] = useState("all");
  const itemsPerPage = 10;

  const { data: whaleAlerts, isLoading: whaleAlertsLoading } = useQuery({
    queryKey: ['/api/whale-alerts'],
    queryFn: () => fetchWhaleAlerts(50),
  });

  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });

  const isLoading = whaleAlertsLoading || subscriptionLoading;
  const userTier = subscription?.tier || "Basic";
  
  // Filter the alerts based on search query and filters
  const filteredAlerts = !whaleAlerts ? [] : whaleAlerts.filter((alert) => {
    // Token filter
    if (tokenFilter !== "all" && alert.token.toLowerCase() !== tokenFilter.toLowerCase()) {
      return false;
    }
    
    // Transaction type filter
    if (transactionTypeFilter !== "all" && 
        alert.transactionType?.toLowerCase() !== transactionTypeFilter.toLowerCase()) {
      return false;
    }
    
    // Search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        alert.token.toLowerCase().includes(query) ||
        alert.fromAddress.toLowerCase().includes(query) ||
        alert.toAddress.toLowerCase().includes(query) ||
        alert.fromLabel?.toLowerCase().includes(query) ||
        alert.toLabel?.toLowerCase().includes(query)
      );
    }
    
    return true;
  });
  
  const totalPages = filteredAlerts ? Math.ceil(filteredAlerts.length / itemsPerPage) : 1;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredAlerts?.slice(indexOfFirstItem, indexOfLastItem) || [];

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // Get unique tokens for filter
  const uniqueTokens = whaleAlerts 
    ? Array.from(new Set(whaleAlerts.map(alert => alert.token)))
    : [];
    
  // Get unique transaction types for filter
  const uniqueTransactionTypes = whaleAlerts 
    ? Array.from(new Set(whaleAlerts.map(alert => alert.transactionType).filter(Boolean)))
    : [];

  if (isLoading) {
    return (
      <div>
        <div className="mb-8">
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Whale Alerts</h2>
          <p className="text-stellar-gray text-sm">Track large cryptocurrency transactions</p>
        </div>
        
        <div className="glassmorphism rounded-xl mb-6 p-6">
          <Skeleton className="h-32 w-full" />
        </div>
        
        <div className="glassmorphism rounded-xl p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <Skeleton className="h-10 w-full md:w-1/2" />
            <div className="flex gap-2 w-full md:w-1/2">
              <Skeleton className="h-10 w-1/2" />
              <Skeleton className="h-10 w-1/2" />
            </div>
          </div>
        </div>
        
        <div className="glassmorphism rounded-xl overflow-hidden">
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8 flex flex-col lg:flex-row lg:items-center justify-between">
        <div>
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Whale Alerts</h2>
          <p className="text-stellar-gray text-sm">Track large cryptocurrency transactions</p>
        </div>
      </div>

      {/* Explanation Card */}
      <div className="glassmorphism rounded-xl p-6 mb-6 border border-neon-blue/30">
        <div className="flex items-start">
          <Waves className="h-8 w-8 text-neon-blue mr-3 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-orbitron font-semibold mb-2">About Whale Alerts</h3>
            <p className="text-stellar-gray text-sm mb-4">
              Whale alerts track large cryptocurrency transactions that may impact the market. These transactions often 
              represent institutional money movement, exchange transfers, or large investor activity. 
              Monitoring these movements can provide insights into potential market shifts.
            </p>
            <div className="flex flex-wrap gap-3 text-xs">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center px-2 py-1 rounded-full bg-neon-green/20 text-neon-green cursor-help">
                      <Info className="h-3 w-3 mr-1" />
                      <span className="font-medium">Exchange Deposit</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="bg-space-blue border-neon-blue/30 text-stellar-white">
                    <p>Large amounts sent to exchanges - often precedes selling pressure</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex items-center px-2 py-1 rounded-full bg-neon-yellow/20 text-neon-yellow cursor-help">
                      <Info className="h-3 w-3 mr-1" />
                      <span className="font-medium">Exchange Withdrawal</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="bg-space-blue border-neon-blue/30 text-stellar-white">
                    <p>Large amounts withdrawn from exchanges - often indicates custody or holding</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filter Bar */}
      <div className="glassmorphism rounded-xl p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-stellar-gray" />
            <Input
              type="text"
              placeholder="Search by token, address or label..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1); // Reset to first page on new search
              }}
              className="pl-10 bg-space-midnight border-neon-blue/20"
            />
          </div>
          
          <div className="flex gap-2">
            <Select value={tokenFilter} onValueChange={(value) => {
              setTokenFilter(value);
              setCurrentPage(1); // Reset to first page on filter change
            }}>
              <SelectTrigger className="bg-space-blue border-neon-blue/20">
                <SelectValue placeholder="Filter by Token" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tokens</SelectItem>
                {uniqueTokens.map(token => (
                  <SelectItem key={token} value={token}>{token}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={transactionTypeFilter} onValueChange={(value) => {
              setTransactionTypeFilter(value);
              setCurrentPage(1); // Reset to first page on filter change
            }}>
              <SelectTrigger className="bg-space-blue border-neon-blue/20">
                <SelectValue placeholder="Filter by Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {uniqueTransactionTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Whale Alerts Table */}
      <div className="glassmorphism rounded-xl overflow-hidden">
        <div className="p-4 border-b border-neon-blue/20 flex justify-between items-center">
          <h4 className="font-medium">
            {filteredAlerts.length === 0 
              ? "No transactions found" 
              : `Showing ${indexOfFirstItem + 1} - ${Math.min(indexOfLastItem, filteredAlerts.length)} of ${filteredAlerts.length} transactions`}
          </h4>
        </div>
        
        {filteredAlerts.length === 0 ? (
          <div className="p-8 text-center">
            <Waves className="h-12 w-12 mx-auto text-neon-blue mb-3" />
            <h3 className="text-xl font-semibold mb-2">No whale alerts found</h3>
            <p className="text-stellar-gray">
              No transactions match your search criteria. Try adjusting your filters.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-b border-neon-blue/20">
                  <TableHead className="text-stellar-gray">Token</TableHead>
                  <TableHead className="text-stellar-gray">Amount</TableHead>
                  <TableHead className="text-stellar-gray">Value (USD)</TableHead>
                  <TableHead className="text-stellar-gray">From</TableHead>
                  <TableHead className="text-stellar-gray">To</TableHead>
                  <TableHead className="text-stellar-gray">Time</TableHead>
                  <TableHead className="text-stellar-gray">Type</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currentItems.map((alert) => {
                  const canAccess = canAccessTier(userTier, alert.requiredTier);
                  
                  return (
                    <TableRow key={alert.id} className="border-b border-neon-blue/10">
                      <TableCell>
                        <div className="flex items-center">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-2 text-xs ${
                            alert.token.toLowerCase() === "btc" ? "bg-[#F7931A]" : 
                            alert.token.toLowerCase() === "eth" ? "bg-[#627EEA]" :
                            alert.token.toLowerCase() === "doge" ? "bg-[#C3A634]" :
                            alert.token.toLowerCase() === "shib" ? "bg-[#E42D04]" :
                            "bg-[#26A17B]"
                          }`}>
                            {alert.token.toLowerCase() === "btc" ? "₿" : 
                             alert.token.toLowerCase() === "eth" ? "Ξ" : 
                             alert.token.toLowerCase() === "doge" ? "Ð" : 
                             alert.token.toLowerCase() === "shib" ? "🐕" : "₮"}
                          </div>
                          <span className={!canAccess ? "blur-sm" : ""}>{alert.token}</span>
                        </div>
                      </TableCell>
                      <TableCell className={!canAccess ? "blur-sm" : ""}>{alert.amount}</TableCell>
                      <TableCell className={`font-medium ${!canAccess ? "blur-sm" : ""}`}>
                        {alert.amountUsd}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className={`text-neon-blue ${!canAccess ? "blur-sm" : ""}`}>
                            {shortenAddress(alert.fromAddress)}
                          </span>
                          {alert.fromLabel && (
                            <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-neon-blue/10 text-neon-blue">
                              {alert.fromLabel}
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className={`text-neon-blue ${!canAccess ? "blur-sm" : ""}`}>
                            {shortenAddress(alert.toAddress)}
                          </span>
                          {alert.toLabel && (
                            <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-neon-blue/10 text-neon-blue">
                              {alert.toLabel}
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-stellar-gray">
                        {formatTimeAgo(new Date(alert.timestamp))}
                      </TableCell>
                      <TableCell>
                        {alert.transactionType && (
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            alert.transactionType === "Exchange Withdrawal" 
                              ? "bg-neon-yellow/20 text-neon-yellow" 
                              : "bg-neon-green/20 text-neon-green"
                          }`}>
                            {alert.transactionType}
                          </span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
        
        {filteredAlerts.length > 0 && (
          <div className="p-4 border-t border-neon-blue/20 flex justify-between items-center">
            <div className="text-sm text-stellar-gray">
              {`Page ${currentPage} of ${totalPages}`}
            </div>
            <div className="flex items-center space-x-2">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={prevPage} 
                disabled={currentPage === 1}
                className="w-8 h-8 rounded flex items-center justify-center hover:bg-space-blue disabled:opacity-50"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">{currentPage} of {totalPages}</span>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={nextPage} 
                disabled={currentPage === totalPages}
                className="w-8 h-8 rounded flex items-center justify-center hover:bg-space-blue disabled:opacity-50"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
