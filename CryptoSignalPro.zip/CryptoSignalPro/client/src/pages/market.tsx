import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchCoins } from "@/lib/api";
import { Coin } from "@/types";
import CoinCard from "@/components/coins/CoinCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, TrendingUp, SortAsc, SortDesc } from "lucide-react";

export default function Market() {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("market_cap_rank");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  
  const { data: coins, isLoading } = useQuery({
    queryKey: ['/api/coins'],
    queryFn: fetchCoins,
  });

  const handleSort = (field: string) => {
    if (sortBy === field) {
      // Toggle sort order if same field
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      // Set new field and default to ascending
      setSortBy(field);
      setSortOrder("asc");
    }
  };

  const filteredAndSortedCoins = coins
    ? coins
        .filter(coin => 
          coin.name.toLowerCase().includes(search.toLowerCase()) || 
          coin.symbol.toLowerCase().includes(search.toLowerCase())
        )
        .sort((a, b) => {
          const fieldA = a[sortBy as keyof Coin];
          const fieldB = b[sortBy as keyof Coin];
          
          if (typeof fieldA === 'number' && typeof fieldB === 'number') {
            return sortOrder === "asc" ? fieldA - fieldB : fieldB - fieldA;
          }
          
          // String comparison
          if (typeof fieldA === 'string' && typeof fieldB === 'string') {
            return sortOrder === "asc" 
              ? fieldA.localeCompare(fieldB) 
              : fieldB.localeCompare(fieldA);
          }
          
          return 0;
        })
    : [];

  return (
    <div>
      <div className="mb-8 flex flex-col lg:flex-row lg:items-center justify-between">
        <div>
          <h2 className="text-2xl lg:text-3xl font-orbitron font-bold text-stellar-white mb-1">Market</h2>
          <p className="text-stellar-gray text-sm">View and track all cryptocurrencies in real-time</p>
        </div>
      </div>

      {/* Search and Filter Bar */}
      <div className="mb-6 glassmorphism rounded-lg p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-stellar-gray" />
            <Input
              type="text"
              placeholder="Search by name or symbol..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-space-midnight border-neon-blue/20"
            />
          </div>
          
          <div className="flex gap-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px] bg-space-blue border-neon-blue/20">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="market_cap_rank">Market Cap Rank</SelectItem>
                <SelectItem value="current_price">Price</SelectItem>
                <SelectItem value="price_change_percentage_24h">24h Change</SelectItem>
                <SelectItem value="market_cap">Market Cap</SelectItem>
                <SelectItem value="total_volume">Volume</SelectItem>
              </SelectContent>
            </Select>
            
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="bg-space-blue border-neon-blue/20"
            >
              {sortOrder === "asc" ? (
                <SortAsc className="h-4 w-4" />
              ) : (
                <SortDesc className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Coins Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {[...Array(12)].map((_, index) => (
            <div key={index} className="glassmorphism rounded-xl p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <Skeleton className="h-8 w-8 rounded-full mr-2" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
                <Skeleton className="h-4 w-4 rounded-full" />
              </div>
              <Skeleton className="h-7 w-32 mb-3" />
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-24" />
              </div>
              <Skeleton className="h-12 w-full mt-3" />
            </div>
          ))}
        </div>
      ) : filteredAndSortedCoins.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredAndSortedCoins.map(coin => (
            <CoinCard key={coin.id} coin={coin} />
          ))}
        </div>
      ) : (
        <div className="glassmorphism rounded-xl p-8 text-center">
          <TrendingUp className="h-12 w-12 mx-auto text-neon-blue mb-3" />
          <h3 className="text-xl font-semibold mb-2">No coins found</h3>
          <p className="text-stellar-gray">
            No cryptocurrencies match your search criteria. Try adjusting your filters.
          </p>
        </div>
      )}
    </div>
  );
}
