export interface Coin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  fully_diluted_valuation: number;
  total_volume: number;
  high_24h: number;
  low_24h: number;
  price_change_24h: number;
  price_change_percentage_24h: number;
  market_cap_change_24h: number;
  market_cap_change_percentage_24h: number;
  circulating_supply: number;
  total_supply: number;
  max_supply: number;
  ath: number;
  ath_change_percentage: number;
  ath_date: string;
  atl: number;
  atl_change_percentage: number;
  atl_date: string;
  last_updated: string;
}

export interface CoinDetail extends Coin {
  description: { en: string };
  links: {
    homepage: string[];
    blockchain_site: string[];
    official_forum_url: string[];
    chat_url: string[];
    announcement_url: string[];
    twitter_screen_name: string;
    facebook_username: string;
    reddit_url: string;
    repos_url: { github: string[] };
  };
  image: {
    thumb: string;
    small: string;
    large: string;
  };
  market_data: {
    current_price: { [key: string]: number };
    market_cap: { [key: string]: number };
    total_volume: { [key: string]: number };
    price_change_percentage_24h: number;
    price_change_percentage_7d: number;
    price_change_percentage_30d: number;
    price_change_percentage_1y: number;
  };
  community_data: {
    twitter_followers: number;
    reddit_subscribers: number;
  };
  developer_data: {
    forks: number;
    stars: number;
    subscribers: number;
    total_issues: number;
    pull_requests_merged: number;
    pull_request_contributors: number;
    commit_count_4_weeks: number;
  };
}

export interface AIPrediction {
  id: number;
  coinId: string;
  timestamp: string;
  signal: string;
  confidence: number;
  riskLevel: string;
  shortTermPrice: string;
  longTermPrice: string;
  stopLoss: string;
  analysis: string;
  accuracy: number;
  requiredTier: string;
}

export interface WhaleAlert {
  id: number;
  transactionId: string;
  token: string;
  amount: string;
  amountUsd: string;
  fromAddress: string;
  toAddress: string;
  fromLabel: string | null;
  toLabel: string | null;
  timestamp: string;
  transactionType: string | null;
  blockchain: string;
  requiredTier: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  paypalPlanId: string;
  features: {
    included: string[];
    excluded: string[];
  };
  popular?: boolean;
  premium?: boolean;
}

export interface User {
  id: number;
  username: string;
  email: string;
  displayName: string | null;
  avatarUrl: string | null;
  subscriptionTier: string;
  subscriptionId: string | null;
  lastLogin: string | null;
  isAdmin: boolean;
  createdAt: string;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    borderColor: string;
    backgroundColor: string;
    fill?: boolean;
    tension?: number;
  }[];
}

export interface CryptoConversion {
  from: {
    amount: number;
    currency: string;
  };
  to: {
    amount: number;
    currency: string;
  };
}
