import { useQuery } from "@tanstack/react-query";
import { fetchSubscriptionPlans, fetchUserSubscription } from "@/lib/api";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import PayPalButton from "./PayPalButton";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";
import { useState } from "react";

export default function SubscriptionPlans() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const { data: plans, isLoading: plansLoading } = useQuery({
    queryKey: ['/api/subscriptions/plans'],
    queryFn: fetchSubscriptionPlans,
  });

  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });

  const isLoading = plansLoading || subscriptionLoading;
  const userTier = subscription?.tier || "Basic";

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(3)].map((_, index) => (
          <div key={index} className="glassmorphism rounded-xl overflow-hidden">
            <div className="p-6 border-b border-neon-blue/20">
              <Skeleton className="h-5 w-24 mb-1" />
              <Skeleton className="h-4 w-48 mb-4" />
              <Skeleton className="h-8 w-32 mb-4" />
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="p-6">
              <Skeleton className="h-4 w-24 mb-3" />
              <div className="space-y-2">
                {[...Array(7)].map((_, idx) => (
                  <Skeleton key={idx} className="h-5 w-full" />
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!plans || plans.length === 0) {
    return (
      <div className="glassmorphism rounded-xl p-6 text-center">
        <p>Subscription plans are currently unavailable. Please try again later.</p>
      </div>
    );
  }

  // Handler for when PayPal button is clicked
  const handlePlanSelect = (planId: string) => {
    setSelectedPlan(planId);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {plans.map((plan) => {
        const isCurrentPlan = userTier === plan.name;
        const isHigherTier = 
          (userTier === "Pro" && plan.name === "Basic") || 
          (userTier === "Premium" && (plan.name === "Basic" || plan.name === "Pro"));
        
        return (
          <div 
            key={plan.id} 
            className={`glassmorphism rounded-xl overflow-hidden ${
              plan.popular ? "neon-border" : 
              plan.premium ? "neon-border neon-border-pink" : ""
            }`}
          >
            <div className="p-6 border-b border-neon-blue/20">
              {plan.popular && (
                <div className="bg-neon-blue text-space-darkBlue text-xs font-medium py-1 px-3 rounded-full inline-block mb-2">
                  Most Popular
                </div>
              )}
              {plan.premium && (
                <div className="bg-neon-pink text-space-darkBlue text-xs font-medium py-1 px-3 rounded-full inline-block mb-2">
                  Premium Access
                </div>
              )}
              <h4 className="text-lg font-bold mb-1">{plan.name} Plan</h4>
              <p className="text-stellar-gray text-sm mb-4">
                {plan.name === "Basic" 
                  ? "Essential crypto data and tools" 
                  : plan.name === "Pro"
                  ? "Advanced features for serious traders"
                  : "Ultimate crypto trading toolkit"
                }
              </p>
              
              <div className="flex items-end mb-4">
                <span className="text-3xl font-bold">
                  {formatCurrency(plan.price, plan.currency)}
                </span>
                <span className="text-stellar-gray text-sm ml-2">/month</span>
              </div>
              
              {isCurrentPlan ? (
                <Button 
                  disabled
                  className="w-full py-2.5 rounded-lg bg-space-blue border border-neon-blue/30 hover:bg-neon-blue/20"
                >
                  Current Plan
                </Button>
              ) : isHigherTier ? (
                <Button 
                  disabled
                  className="w-full py-2.5 rounded-lg bg-space-blue border border-neon-blue/30 hover:bg-neon-blue/20"
                >
                  Lower Tier
                </Button>
              ) : (
                <div>
                  {selectedPlan === plan.id ? (
                    <div className="my-2">
                      <PayPalButton 
                        amount={plan.price.toString()} 
                        currency={plan.currency} 
                        intent="subscription"
                      />
                    </div>
                  ) : (
                    <Button 
                      onClick={() => handlePlanSelect(plan.id)}
                      className={`w-full py-2.5 rounded-lg ${
                        plan.name === "Pro" 
                          ? "bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90" 
                          : plan.name === "Premium" 
                          ? "bg-neon-pink text-space-darkBlue hover:bg-neon-pink/90"
                          : "bg-space-blue border border-neon-blue/30 hover:bg-neon-blue/20"
                      } font-medium`}
                    >
                      {plan.name === "Basic" 
                        ? "Subscribe to Basic" 
                        : plan.name === "Pro" 
                        ? "Upgrade to Pro" 
                        : "Go Premium"
                      }
                    </Button>
                  )}
                </div>
              )}
            </div>
            
            <div className="p-6">
              <h5 className="font-medium mb-3">Features</h5>
              <ul className="space-y-2">
                {plan.features.included.map((feature, idx) => (
                  <li key={`included-${idx}`} className="flex items-start">
                    <Check className="h-4 w-4 text-neon-green mr-2 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
                
                {plan.features.excluded.map((feature, idx) => (
                  <li key={`excluded-${idx}`} className="flex items-start">
                    <X className="h-4 w-4 text-stellar-gray mr-2 mt-0.5" />
                    <span className="text-sm text-stellar-gray">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        );
      })}
    </div>
  );
}
