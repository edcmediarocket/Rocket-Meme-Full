import React from "react";
import { SelectItem } from "@/components/ui/select";

interface SafeSelectItemProps {
  value: string | undefined;
  children: React.ReactNode;
  className?: string;
  // Add other props that SelectItem might accept
}

/**
 * A wrapper around SelectItem that ensures the value prop is never empty
 */
export function SafeSelectItem({ value, children, ...props }: SafeSelectItemProps) {
  // Ensure value is never empty (which causes the error)
  const safeValue = value || "placeholder-value";
  
  return (
    <SelectItem value={safeValue} {...props}>
      {children}
    </SelectItem>
  );
}