import { Link } from "wouter";
import { Coin } from "@/types";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { fetchWatchlist, addToWatchlist, removeFromWatchlist } from "@/lib/api";
import { Star } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface CoinCardProps {
  coin: Coin;
}

export default function CoinCard({ coin }: CoinCardProps) {
  const { data: watchlist } = useQuery({
    queryKey: ['/api/user/watchlist'],
    queryFn: fetchWatchlist,
  });

  // Handle case when there's no watchlist data or user isn't logged in
  const isInWatchlist = watchlist ? watchlist.some(watchlistCoin => watchlistCoin.id === coin.id) : false;

  const handleWatchlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      if (isInWatchlist) {
        await removeFromWatchlist(coin.id);
        toast({
          title: "Removed from watchlist",
          description: `${coin.name} has been removed from your watchlist.`,
        });
      } else {
        await addToWatchlist(coin.id);
        toast({
          title: "Added to watchlist",
          description: `${coin.name} has been added to your watchlist.`,
        });
      }
      
      // Invalidate watchlist query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/user/watchlist'] });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error updating your watchlist.",
        variant: "destructive",
      });
    }
  };

  const getCoinSymbol = (id: string): string => {
    switch (id) {
      case "bitcoin": return "₿";
      case "ethereum": return "Ξ";
      case "dogecoin": return "Ð";
      case "shiba-inu": return "🐕";
      default: return coin.symbol.charAt(0).toUpperCase();
    }
  };

  const getCoinBgColor = (id: string): string => {
    switch (id) {
      case "bitcoin": return "bg-[#F7931A]";
      case "ethereum": return "bg-[#627EEA]";
      case "dogecoin": return "bg-[#C3A634]";
      case "shiba-inu": return "bg-[#E42D04]";
      default: return "bg-gray-500";
    }
  };

  const priceChangeColor = coin.price_change_percentage_24h >= 0 ? "text-neon-green" : "text-neon-red";
  const priceChangeIcon = coin.price_change_percentage_24h >= 0 ? "arrow_upward" : "arrow_downward";

  // Fix for nested <a> tag issue
  return (
    <div 
      className="glassmorphism rounded-xl p-4 neon-border block cursor-pointer"
      onClick={(e) => {
        // Only navigate if not clicking on watchlist button
        if ((e.target as Element).closest('button') === null) {
          window.location.href = `/coin/${coin.id}`;
        }
      }}
    >
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center">
          <div className={`w-8 h-8 rounded-full ${getCoinBgColor(coin.id)} flex items-center justify-center mr-2`}>
            {getCoinSymbol(coin.id)}
          </div>
          <div>
            <h4 className="font-semibold">{coin.name}</h4>
            <p className="text-xs text-stellar-gray">{coin.symbol.toUpperCase()}</p>
          </div>
        </div>
        <button 
          onClick={handleWatchlist}
          className={`text-stellar-gray hover:text-neon-blue ${isInWatchlist ? 'text-neon-blue' : ''}`}
        >
          <Star className="h-4 w-4" fill={isInWatchlist ? "currentColor" : "none"} />
        </button>
      </div>
      
      <div className="text-2xl font-bold mb-3">
        {formatCurrency(coin.current_price)}
      </div>
      
      <div className="flex items-center justify-between">
        <div className={`flex items-center ${priceChangeColor}`}>
          <span className="material-icons text-sm mr-1">{priceChangeIcon}</span>
          <span className="text-sm">{formatPercentage(coin.price_change_percentage_24h)}</span>
        </div>
        <div className="text-xs text-stellar-gray">
          24h Volume: {formatCurrency(coin.total_volume, "USD", true)}
        </div>
      </div>
      
      {/* Mini Chart */}
      <div className="h-12 mt-3 relative">
        <svg width="100%" height="100%" viewBox="0 0 100 30">
          <path 
            className="chart-line" 
            d={generateChartPath(coin.price_change_percentage_24h)}
            fill="none" 
            stroke={coin.price_change_percentage_24h >= 0 ? "#36F9B3" : "#FF4A4A"} 
            strokeWidth="1.5"
          />
        </svg>
      </div>
    </div>
  );
}

// Helper function to generate a chart path based on price change
function generateChartPath(priceChange: number): string {
  // For demo purposes, generate a simple path based on whether price is increasing or decreasing
  if (priceChange >= 0) {
    // Upward trend
    return "M0,20 L5,19 L10,22 L15,17 L20,18 L25,15 L30,16 L35,13 L40,15 L45,12 L50,13 L55,10 L60,12 L65,8 L70,10 L75,7 L80,9 L85,5 L90,6 L95,4 L100,2";
  } else {
    // Downward trend
    return "M0,10 L5,12 L10,9 L15,11 L20,8 L25,10 L30,12 L35,14 L40,13 L45,15 L50,18 L55,17 L60,19 L65,20 L70,18 L75,20 L80,22 L85,21 L90,23 L95,22 L100,24";
  }
}
