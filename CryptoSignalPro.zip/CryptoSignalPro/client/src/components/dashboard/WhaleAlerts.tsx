import { useQuery } from "@tanstack/react-query";
import { fetchWhaleAlerts, fetchUserSubscription } from "@/lib/api";
import { Link } from "wouter";
import { 
  Waves, 
  Filter, 
  ChevronLeft, 
  ChevronRight, 
  ExternalLink 
} from "lucide-react";
import { 
  formatCurrency, 
  shortenAddress, 
  formatTimeAgo,
  canAccessTier
} from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

export default function WhaleAlerts() {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 3;

  const { data: whaleAlerts, isLoading: whaleAlertsLoading } = useQuery({
    queryKey: ['/api/whale-alerts'],
    queryFn: () => fetchWhaleAlerts(10),
  });

  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });

  const isLoading = whaleAlertsLoading || subscriptionLoading;
  const userTier = subscription?.tier || "Basic";
  
  const totalPages = whaleAlerts ? Math.ceil(whaleAlerts.length / itemsPerPage) : 1;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = whaleAlerts?.slice(indexOfFirstItem, indexOfLastItem) || [];

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  if (isLoading) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <Waves className="h-5 w-5 mr-2 text-neon-blue" />
          Whale Alerts
          <div className="ml-2 w-2 h-2 bg-neon-pink rounded-full animate-pulse"></div>
        </h3>
        
        <div className="glassmorphism rounded-xl overflow-hidden">
          <div className="p-4 border-b border-neon-blue/20 flex justify-between items-center">
            <Skeleton className="h-6 w-48" />
            <div className="flex space-x-2">
              <Skeleton className="h-8 w-24" />
              <Skeleton className="h-8 w-24" />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <div className="p-4">
              <Skeleton className="h-48 w-full" />
            </div>
          </div>
          
          <div className="p-4 border-t border-neon-blue/20 flex justify-between items-center">
            <Skeleton className="h-5 w-36" />
            <div className="flex items-center space-x-2">
              <Skeleton className="h-8 w-8 rounded" />
              <Skeleton className="h-5 w-12" />
              <Skeleton className="h-8 w-8 rounded" />
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (!whaleAlerts || whaleAlerts.length === 0) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <Waves className="h-5 w-5 mr-2 text-neon-blue" />
          Whale Alerts
          <div className="ml-2 w-2 h-2 bg-neon-pink rounded-full animate-pulse"></div>
        </h3>
        
        <div className="glassmorphism rounded-xl p-6 text-center">
          <p>No whale alerts available at the moment. Check back later.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
        <Waves className="h-5 w-5 mr-2 text-neon-blue" />
        Whale Alerts
        <div className="ml-2 w-2 h-2 bg-neon-pink rounded-full animate-pulse"></div>
      </h3>
      
      <div className="glassmorphism rounded-xl overflow-hidden">
        <div className="p-4 border-b border-neon-blue/20 flex justify-between items-center">
          <h4 className="font-medium">Recent Large Transactions</h4>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="px-3 py-1 text-xs rounded-lg bg-space-blue border border-neon-blue/20 hover:bg-neon-blue/20">
              All Chains
            </Button>
            <Button variant="outline" size="sm" className="px-3 py-1 text-xs rounded-lg bg-space-blue border border-neon-blue/20 hover:bg-neon-blue/20">
              <Filter className="h-3 w-3 mr-1" />
              Filter
            </Button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-b border-neon-blue/20">
                <TableHead className="text-stellar-gray">Token</TableHead>
                <TableHead className="text-stellar-gray">Amount</TableHead>
                <TableHead className="text-stellar-gray">Value (USD)</TableHead>
                <TableHead className="text-stellar-gray">From</TableHead>
                <TableHead className="text-stellar-gray">To</TableHead>
                <TableHead className="text-stellar-gray">Time</TableHead>
                <TableHead className="text-stellar-gray">Type</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentItems.map((alert) => {
                const canAccess = canAccessTier(userTier, alert.requiredTier);
                
                return (
                  <TableRow key={alert.id} className="border-b border-neon-blue/10">
                    <TableCell>
                      <div className="flex items-center">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-2 text-xs ${
                          alert.token.toLowerCase() === "btc" ? "bg-[#F7931A]" : 
                          alert.token.toLowerCase() === "eth" ? "bg-[#627EEA]" :
                          alert.token.toLowerCase() === "doge" ? "bg-[#C3A634]" :
                          alert.token.toLowerCase() === "shib" ? "bg-[#E42D04]" :
                          "bg-[#26A17B]"
                        }`}>
                          {alert.token.toLowerCase() === "btc" ? "₿" : 
                           alert.token.toLowerCase() === "eth" ? "Ξ" : 
                           alert.token.toLowerCase() === "doge" ? "Ð" : 
                           alert.token.toLowerCase() === "shib" ? "🐕" : "₮"}
                        </div>
                        <span className={!canAccess ? "blur-sm" : ""}>{alert.token}</span>
                      </div>
                    </TableCell>
                    <TableCell className={!canAccess ? "blur-sm" : ""}>{alert.amount}</TableCell>
                    <TableCell className={`font-medium ${!canAccess ? "blur-sm" : ""}`}>
                      {alert.amountUsd}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className={`text-neon-blue ${!canAccess ? "blur-sm" : ""}`}>
                          {shortenAddress(alert.fromAddress)}
                        </span>
                        {alert.fromLabel && (
                          <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-neon-blue/10 text-neon-blue">
                            {alert.fromLabel}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <span className={`text-neon-blue ${!canAccess ? "blur-sm" : ""}`}>
                          {shortenAddress(alert.toAddress)}
                        </span>
                        {alert.toLabel && (
                          <span className="ml-1 px-1.5 py-0.5 text-xs rounded bg-neon-blue/10 text-neon-blue">
                            {alert.toLabel}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-stellar-gray">
                      {formatTimeAgo(new Date(alert.timestamp))}
                    </TableCell>
                    <TableCell>
                      {alert.transactionType && (
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          alert.transactionType === "Exchange Withdrawal" 
                            ? "bg-neon-yellow/20 text-neon-yellow" 
                            : "bg-neon-green/20 text-neon-green"
                        }`}>
                          {alert.transactionType}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        
        <div className="p-4 border-t border-neon-blue/20 flex justify-between items-center">
          <Link href="/whale-alerts">
            <a className="text-neon-blue hover:underline text-sm flex items-center">
              View All Transactions
              <ExternalLink className="h-3 w-3 ml-1" />
            </a>
          </Link>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={prevPage} 
              disabled={currentPage === 1}
              className="w-8 h-8 rounded flex items-center justify-center hover:bg-space-blue disabled:opacity-50"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">{currentPage} of {totalPages}</span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={nextPage} 
              disabled={currentPage === totalPages}
              className="w-8 h-8 rounded flex items-center justify-center hover:bg-space-blue disabled:opacity-50"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
