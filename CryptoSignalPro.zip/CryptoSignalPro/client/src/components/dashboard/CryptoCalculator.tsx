import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calculator, SquareSplitVertical } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { fetchCoins, convertCrypto } from "@/lib/api";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";

export default function CryptoCalculator() {
  const [fromCurrency, setFromCurrency] = useState("BTC");
  const [toCurrency, setToCurrency] = useState("USD");
  const [amount, setAmount] = useState("1");
  const [convertedAmount, setConvertedAmount] = useState<number | null>(null);
  
  const { data: coins, isLoading: coinsLoading } = useQuery({
    queryKey: ['/api/coins'],
    queryFn: fetchCoins,
  });

  const handleSwapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    setConvertedAmount(null); // Reset on swap
  };

  const handleCalculate = async () => {
    try {
      const result = await convertCrypto(fromCurrency, toCurrency, parseFloat(amount));
      setConvertedAmount(result.amount);
    } catch (error) {
      console.error("Conversion error:", error);
      // Reset on error
      setConvertedAmount(null);
    }
  };

  const cryptoCurrencies = ["BTC", "ETH", "USDT", "DOGE", "SHIB"];
  const fiatCurrencies = ["USD", "EUR", "JPY", "GBP", "AUD"];

  const commonConversions = [
    { from: "BTC", to: "USD", fromDisplay: "₿", fromBg: "bg-[#F7931A]" },
    { from: "ETH", to: "USD", fromDisplay: "Ξ", fromBg: "bg-[#627EEA]" },
    { from: "DOGE", to: "USD", fromDisplay: "Ð", fromBg: "bg-[#C3A634]" },
    { from: "USDT", to: "USD", fromDisplay: "₮", fromBg: "bg-[#26A17B]" },
    { from: "SHIB", to: "USD", fromDisplay: "🐕", fromBg: "bg-[#E42D04]" },
  ];

  if (coinsLoading) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <Calculator className="h-5 w-5 mr-2 text-neon-pink" />
          Conversion Calculator
        </h3>
        
        <div className="glassmorphism rounded-xl p-6 neon-border">
          <Skeleton className="h-64 w-full" />
        </div>
      </section>
    );
  }

  const getCoinPrice = (symbol: string): number => {
    if (symbol === "USD" || symbol === "EUR" || symbol === "JPY" || symbol === "GBP" || symbol === "AUD") {
      return 1; // Fiat currencies
    }
    
    const coin = coins?.find(c => c.symbol.toUpperCase() === symbol.toUpperCase());
    return coin?.current_price || 0;
  };

  return (
    <section className="mb-8">
      <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
        <Calculator className="h-5 w-5 mr-2 text-neon-pink" />
        Conversion Calculator
      </h3>
      
      <div className="glassmorphism rounded-xl p-6 neon-border">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Calculator Inputs */}
          <div>
            <div className="mb-4">
              <label className="block text-sm text-stellar-gray mb-2">From</label>
              <div className="flex">
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-space-midnight border border-neon-blue/20 rounded-l-lg focus:border-neon-blue"
                />
                <Select value={fromCurrency} onValueChange={setFromCurrency}>
                  <SelectTrigger className="w-28 bg-space-blue border border-neon-blue/20 rounded-r-lg focus:border-neon-blue">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Select</SelectItem>
                    <optgroup label="Cryptocurrencies">
                      {cryptoCurrencies.map(currency => (
                        <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                      ))}
                    </optgroup>
                    <optgroup label="Fiat Currencies">
                      {fiatCurrencies.map(currency => (
                        <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                      ))}
                    </optgroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mb-4 flex justify-center">
              <Button
                onClick={handleSwapCurrencies}
                variant="outline"
                size="icon"
                className="w-10 h-10 rounded-full bg-space-blue hover:bg-neon-blue/20 border-none"
              >
                <SquareSplitVertical className="h-5 w-5" />
              </Button>
            </div>
            
            <div>
              <label className="block text-sm text-stellar-gray mb-2">To</label>
              <div className="flex">
                <Input
                  type="number"
                  value={convertedAmount !== null ? convertedAmount.toString() : ''}
                  readOnly
                  className="w-full bg-space-midnight border border-neon-blue/20 rounded-l-lg focus:border-neon-blue"
                />
                <Select value={toCurrency} onValueChange={setToCurrency}>
                  <SelectTrigger className="w-28 bg-space-blue border border-neon-blue/20 rounded-r-lg focus:border-neon-blue">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Select</SelectItem>
                    <optgroup label="Cryptocurrencies">
                      {cryptoCurrencies.map(currency => (
                        <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                      ))}
                    </optgroup>
                    <optgroup label="Fiat Currencies">
                      {fiatCurrencies.map(currency => (
                        <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                      ))}
                    </optgroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mt-4">
              <Button 
                onClick={handleCalculate}
                className="w-full py-3 rounded-lg bg-neon-blue text-space-darkBlue hover:bg-neon-blue/90 font-medium"
              >
                Calculate
              </Button>
            </div>
          </div>
          
          {/* Common Conversions */}
          <div>
            <h4 className="font-semibold mb-3">Common Conversions</h4>
            <div className="space-y-3">
              {commonConversions.map((conversion, index) => {
                const price = getCoinPrice(conversion.from);
                
                return (
                  <div key={index} className="flex justify-between items-center p-3 rounded-lg bg-space-midnight">
                    <div>
                      <div className="flex items-center">
                        <div className={`w-6 h-6 rounded-full ${conversion.fromBg} flex items-center justify-center mr-2 text-xs`}>
                          {conversion.fromDisplay}
                        </div>
                        <span>1 {conversion.from}</span>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span>=</span>
                      <span className="ml-2">
                        {formatCurrency(price, conversion.to)} {conversion.to}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
