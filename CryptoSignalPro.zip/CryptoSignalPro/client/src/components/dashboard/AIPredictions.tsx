import { useQuery } from "@tanstack/react-query";
import { fetchPredictions, fetchUserSubscription } from "@/lib/api";
import { Link } from "wouter";
import { canAccessTier, getSignalColor, getRiskColor } from "@/lib/utils";
import { Brain, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function AIPredictions() {
  const { data: predictions, isLoading: predictionsLoading } = useQuery({
    queryKey: ['/api/predictions'],
    queryFn: fetchPredictions,
  });

  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: fetchUserSubscription,
  });

  const isLoading = predictionsLoading || subscriptionLoading;
  const userTier = subscription?.tier || "Basic";

  if (isLoading) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <Brain className="h-5 w-5 mr-2 text-neon-pink" />
          AI Predictions
          <span className="ml-2 text-xs bg-neon-pink/20 text-neon-pink px-2 py-1 rounded-full">Premium</span>
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[...Array(2)].map((_, index) => (
            <div key={index} className="glassmorphism rounded-xl overflow-hidden">
              <div className="p-4 border-b border-neon-blue/20">
                <Skeleton className="h-14 w-full" />
              </div>
              <div className="p-4 space-y-4">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-16 w-full" />
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (!predictions || predictions.length === 0) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <Brain className="h-5 w-5 mr-2 text-neon-pink" />
          AI Predictions
          <span className="ml-2 text-xs bg-neon-pink/20 text-neon-pink px-2 py-1 rounded-full">Premium</span>
        </h3>
        
        <div className="glassmorphism rounded-xl p-6 text-center">
          <p>No AI predictions available at the moment. Check back later.</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
        <Brain className="h-5 w-5 mr-2 text-neon-pink" />
        AI Predictions
        <span className="ml-2 text-xs bg-neon-pink/20 text-neon-pink px-2 py-1 rounded-full">Premium</span>
      </h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {predictions.slice(0, 2).map((prediction, index) => {
          const canAccess = canAccessTier(userTier, prediction.requiredTier);
          
          return (
            <div key={prediction.id} className="glassmorphism rounded-xl overflow-hidden relative">
              {!canAccess && (
                <div className="absolute inset-0 flex items-center justify-center z-10 bg-space-darkBlue/50 backdrop-blur-sm">
                  <div className="text-center p-6">
                    <div className="w-16 h-16 rounded-full bg-neon-pink/20 flex items-center justify-center mx-auto mb-4">
                      <Lock className="h-8 w-8 text-neon-pink" />
                    </div>
                    <h4 className="text-xl font-orbitron font-bold mb-2">Premium Content</h4>
                    <p className="text-sm text-stellar-gray mb-4">
                      Upgrade to {prediction.requiredTier} or higher to unlock advanced AI predictions and analysis.
                    </p>
                    <Link href="/subscription">
                      <Button className="bg-neon-pink text-space-darkBlue hover:bg-neon-pink/90 font-medium">
                        Upgrade Now
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
              
              <div className={!canAccess ? "premium-content" : ""}>
                <div className="flex justify-between items-start p-4 border-b border-neon-blue/20">
                  <div className="flex items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                      prediction.coinId === "bitcoin" ? "bg-[#F7931A]" : 
                      prediction.coinId === "ethereum" ? "bg-[#627EEA]" :
                      prediction.coinId === "dogecoin" ? "bg-[#C3A634]" :
                      "bg-[#E42D04]"
                    }`}>
                      {prediction.coinId === "bitcoin" ? "₿" : 
                       prediction.coinId === "ethereum" ? "Ξ" : 
                       prediction.coinId === "dogecoin" ? "Ð" : "🐕"}
                    </div>
                    <div>
                      <h4 className="font-bold capitalize">{prediction.coinId.replace(/-/g, ' ')}</h4>
                      <p className="text-xs text-stellar-gray">Today's Prediction</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-4">
                  <div className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">AI Signal:</span>
                      <span className={`text-sm font-medium ${getSignalColor(prediction.signal)}`}>
                        {prediction.signal}
                      </span>
                    </div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Confidence:</span>
                      <span className="text-sm font-medium">{prediction.confidence}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Risk Level:</span>
                      <span className={`text-sm font-medium ${getRiskColor(prediction.riskLevel)}`}>
                        {prediction.riskLevel}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Short-term Target:</span>
                      <span className="text-sm font-medium text-neon-green">
                        {prediction.shortTermPrice}
                      </span>
                    </div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Long-term Target:</span>
                      <span className="text-sm font-medium text-neon-green">
                        {prediction.longTermPrice}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Stop Loss:</span>
                      <span className="text-sm font-medium text-neon-red">
                        {prediction.stopLoss}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h5 className="text-sm font-semibold mb-2">AI Analysis:</h5>
                    <p className="text-sm text-stellar-gray">{prediction.analysis}</p>
                  </div>
                  
                  <div className="mt-4 flex justify-end">
                    <Link href={`/coin/${prediction.coinId}`}>
                      <Button variant="outline" className="px-3 py-1.5 text-sm rounded-lg bg-neon-blue/20 text-neon-blue hover:bg-neon-blue/30 border-none">
                        View Detailed Analysis
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
