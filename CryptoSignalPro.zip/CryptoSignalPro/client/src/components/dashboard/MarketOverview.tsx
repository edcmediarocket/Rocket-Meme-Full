import { useQuery } from "@tanstack/react-query";
import { fetchCoins } from "@/lib/api";
import CoinCard from "../coins/CoinCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function MarketOverview() {
  const { data: coins, isLoading, error } = useQuery({
    queryKey: ['/api/coins'],
    queryFn: fetchCoins,
  });

  if (isLoading) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <TrendingUpIcon className="h-5 w-5 mr-2 text-neon-blue" />
          Market Overview
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, index) => (
            <div key={index} className="glassmorphism rounded-xl p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <Skeleton className="h-8 w-8 rounded-full mr-2" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
              </div>
              <Skeleton className="h-7 w-32 mb-3" />
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-4 w-24" />
              </div>
              <Skeleton className="h-12 w-full mt-3" />
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
          <TrendingUpIcon className="h-5 w-5 mr-2 text-neon-blue" />
          Market Overview
        </h3>
        <div className="glassmorphism rounded-xl p-6 text-neon-red">
          Error loading market data. Please try again later.
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <h3 className="text-xl font-orbitron font-bold mb-4 flex items-center">
        <TrendingUpIcon className="h-5 w-5 mr-2 text-neon-blue" />
        Market Overview
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {coins?.slice(0, 4).map((coin) => (
          <CoinCard key={coin.id} coin={coin} />
        ))}
      </div>
    </section>
  );
}

function TrendingUpIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
      <polyline points="17 6 23 6 23 12" />
    </svg>
  );
}
