
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { saveAs } from 'file-saver';
import JSZip from 'jszip';

export function ProjectDownloader() {
  const [isDownloading, setIsDownloading] = useState(false);

  const downloadProject = async () => {
    setIsDownloading(true);
    try {
      const response = await fetch('/api/download-project');
      const projectData = await response.json();
      
      const zip = new JSZip();
      
      // Add files to zip
      Object.entries(projectData.files).forEach(([path, content]) => {
        zip.file(path, content);
      });
      
      // Generate and download zip
      const blob = await zip.generateAsync({ type: 'blob' });
      saveAs(blob, 'my-replit-project.zip');
    } catch (error) {
      console.error('Failed to download project:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Button 
      onClick={downloadProject}
      disabled={isDownloading}
    >
      {isDownloading ? 'Downloading...' : 'Download Project'}
    </Button>
  );
}
