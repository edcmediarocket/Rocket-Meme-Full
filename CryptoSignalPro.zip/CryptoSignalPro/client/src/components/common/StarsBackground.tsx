import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  size: number;
  color: string;
  alpha: number;
  speed: number;
}

export default function StarsBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    const container = containerRef.current;
    const stars: Star[] = [];
    const starCount = 150;
    
    // Create stars
    for (let i = 0; i < starCount; i++) {
      const size = Math.random() * 2;
      // Determine color - sometimes use neon colors for accent
      let color;
      const randomValue = Math.random();
      if (randomValue < 0.1) {
        color = '#00E5FF'; // neon blue
      } else if (randomValue < 0.2) {
        color = '#FF16B0'; // neon pink
      } else {
        color = '#ffffff'; // white
      }
      
      stars.push({
        x: Math.random() * 100,
        y: Math.random() * 100,
        size,
        color,
        alpha: Math.random() * 0.8 + 0.2,
        speed: Math.random() * 3 + 2,
      });
    }
    
    // Create star elements
    stars.forEach(star => {
      const starElement = document.createElement('div');
      starElement.className = 'absolute rounded-full';
      starElement.style.width = `${star.size}px`;
      starElement.style.height = `${star.size}px`;
      starElement.style.backgroundColor = star.color;
      starElement.style.left = `${star.x}%`;
      starElement.style.top = `${star.y}%`;
      starElement.style.opacity = star.alpha.toString();
      starElement.style.animation = `pulse ${star.speed}s infinite ease-in-out`;
      
      container.appendChild(starElement);
    });
    
    // Cleanup
    return () => {
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    };
  }, []);
  
  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 z-0 pointer-events-none overflow-hidden"
    />
  );
}
