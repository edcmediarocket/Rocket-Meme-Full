import { cn } from "@/lib/utils";

interface RocketAnimationProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export default function RocketAnimation({ className, size = "md" }: RocketAnimationProps) {
  // SVG implementation of a rocket for better control and consistency
  const rocketSvg = (
    <svg 
      width="100%" 
      height="100%" 
      viewBox="0 0 120 160" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full"
    >
      {/* Rocket Flame Animation */}
      <g className="animate-pulse">
        <path d="M50 115 L60 140 L70 115" fill="#FF5E5B" />
        <path d="M53 115 L60 135 L67 115" fill="#FFBD00" />
        <path d="M56 115 L60 130 L64 115" fill="#FF9B00" />
      </g>
      
      {/* Rocket Body */}
      <path d="M45 50 C45 20 60 10 60 10 C60 10 75 20 75 50 L75 110 L45 110 L45 50Z" fill="#4D5061" stroke="#2D3142" strokeWidth="2" />
      
      {/* Rocket Nose */}
      <path d="M45 50 C45 30 60 20 60 20 C60 20 75 30 75 50 L75 55 L45 55 L45 50Z" fill="#EF8354" stroke="#2D3142" strokeWidth="2" />
      
      {/* Rocket Window */}
      <circle cx="60" cy="70" r="10" fill="#00E5FF" stroke="#2D3142" strokeWidth="2" />
      <circle cx="60" cy="70" r="7" fill="#DADFF7" />
      
      {/* Rocket Fins */}
      <path d="M45 90 L30 105 L45 110 Z" fill="#EF8354" stroke="#2D3142" strokeWidth="2" />
      <path d="M75 90 L90 105 L75 110 Z" fill="#EF8354" stroke="#2D3142" strokeWidth="2" />
      
      {/* Rocket Detail Lines */}
      <line x1="55" y1="35" x2="65" y2="35" stroke="#2D3142" strokeWidth="2" />
      <line x1="53" y1="40" x2="67" y2="40" stroke="#2D3142" strokeWidth="2" />
    </svg>
  );

  const sizeClasses = {
    sm: "w-16 h-16 lg:w-24 lg:h-24",
    md: "w-32 h-32 lg:w-48 lg:h-48",
    lg: "w-40 h-40 lg:w-64 lg:h-64"
  };

  return (
    <div className={cn("relative rocket-animation", sizeClasses[size], className)}>
      {rocketSvg}
    </div>
  );
}
