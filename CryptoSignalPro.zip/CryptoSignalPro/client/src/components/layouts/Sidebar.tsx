import { Link, useLocation } from "wouter";
import { User } from "@/types";
import { cn } from "@/lib/utils";
import { signOut } from "@/lib/firebase";
import { 
  Home, 
  TrendingUp, 
  Brain, 
  Waves, 
  Calculator, 
  Star, 
  Award, 
  LogOut,
  ChevronLeft,
  Users
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  user: User | null;
  className?: string;
  onClose?: () => void;
  isMobile?: boolean;
}

export default function Sidebar({ user, className, onClose, isMobile = false }: SidebarProps) {
  const [location] = useLocation();
  
  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: <Home className="h-5 w-5 mr-3" /> },
    { path: "/market", label: "Market", icon: <TrendingUp className="h-5 w-5 mr-3" /> },
    { path: "/ai-predictions", label: "AI Predictions", icon: <Brain className="h-5 w-5 mr-3" /> },
    { path: "/whale-alerts", label: "Whale Alerts", icon: <Waves className="h-5 w-5 mr-3" /> },
    { path: "/calculator", label: "Calculator", icon: <Calculator className="h-5 w-5 mr-3" /> },
    { path: "/watchlist", label: "Watchlist", icon: <Star className="h-5 w-5 mr-3" /> },
    { path: "/subscription", label: "Subscription", icon: <Award className="h-5 w-5 mr-3" /> },
  ];

  // Admin-only items
  if (user?.isAdmin) {
    navItems.push({ path: "/admin", label: "Admin", icon: <Users className="h-5 w-5 mr-3" /> });
  }

  const handleLogout = async () => {
    try {
      await signOut();
      window.location.href = "/login";
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };
  
  // Overlay for mobile sidebar
  const renderOverlay = () => {
    if (isMobile && onClose) {
      return (
        <div 
          className="absolute inset-0 bg-black bg-opacity-50" 
          onClick={onClose}
        />
      );
    }
    return null;
  };

  return (
    <aside className={cn("w-64 fixed h-screen glassmorphism border-r border-neon-blue/20 z-40 overflow-auto", className)}>
      {renderOverlay()}
      
      <div className="relative z-10">
        <div className="p-6">
          {/* Header with close button for mobile */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <span className="text-3xl animate-float">🚀</span>
              <h1 className="font-orbitron text-2xl ml-2 font-bold bg-gradient-to-r from-neon-blue to-neon-pink text-transparent bg-clip-text">
                Rocket Meme
              </h1>
            </div>
            
            {isMobile && onClose && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onClose} 
                className="text-white"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
            )}
          </div>
          
          <nav className="space-y-2">
            {navItems.map((item) => {
              const isActive = location === item.path || 
                (item.path !== "/dashboard" && location.startsWith(item.path));
              
              return (
                <div
                  key={item.path}
                  onClick={() => window.location.href = item.path}
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all cursor-pointer",
                    isActive 
                      ? "bg-neon-blue/10 border border-neon-blue/50 text-neon-blue" 
                      : "text-stellar-white hover:bg-space-midnight"
                  )}>
                  {item.icon}
                  <span className="font-medium">{item.label}</span>
                  
                  {/* Notification dot for Whale Alerts */}
                  {item.path === "/whale-alerts" && (
                    <div className="ml-auto h-2 w-2 bg-neon-pink rounded-full animate-pulse"></div>
                  )}
                </div>
              );
            })}
            
            {user && (
              <button 
                onClick={handleLogout}
                className="flex items-center w-full px-4 py-3 rounded-lg text-stellar-white hover:bg-space-midnight transition-all"
              >
                <LogOut className="h-5 w-5 mr-3" />
                <span className="font-medium">Logout</span>
              </button>
            )}
          </nav>
        </div>
        
        {/* User Profile */}
        {user && (
          <div className="absolute bottom-0 left-0 right-0 p-4 glassmorphism border-t border-neon-blue/20">
            <div className="flex items-center">
              <Avatar className="h-10 w-10 border-2 border-neon-blue">
                <AvatarImage src={user.avatarUrl || undefined} />
                <AvatarFallback className="bg-space-blue text-white">
                  {user.displayName?.charAt(0) || user.username.charAt(0)}
                </AvatarFallback>
              </Avatar>
              
              <div className="ml-3">
                <p className="text-sm font-semibold">{user.displayName || user.username}</p>
                <div className="flex items-center">
                  <span className="text-xs text-stellar-gray">{user.subscriptionTier} Plan</span>
                  
                  {user.subscriptionTier !== "Premium" && (
                    <Link href="/subscription">
                      <a className="ml-2 px-2 py-0.5 bg-neon-blue/20 rounded text-neon-blue text-xs">
                        Upgrade
                      </a>
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
