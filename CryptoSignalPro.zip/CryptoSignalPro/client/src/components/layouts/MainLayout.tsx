import { useState, useEffect } from "react";
import { User } from "@/types";
import Sidebar from "./Sidebar";
import MobileNav from "./MobileNav";
import StarsBackground from "../common/StarsBackground";
import { cn } from "@/lib/utils";

interface MainLayoutProps {
  children: React.ReactNode;
  user: User | null;
}

export default function MainLayout({ children, user }: MainLayoutProps) {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Close mobile sidebar on route change
  useEffect(() => {
    setMobileSidebarOpen(false);
  }, [children]);

  return (
    <div className="min-h-screen bg-space-darkBlue text-white font-exo relative">
      {/* Stars Background */}
      <StarsBackground />
      
      {/* Mobile Header */}
      <MobileNav 
        user={user} 
        onOpenSidebar={() => setMobileSidebarOpen(true)} 
      />
      
      {/* Main Container */}
      <div className="flex min-h-screen relative z-10">
        {/* Sidebar - Desktop */}
        <Sidebar 
          user={user}
          className="hidden lg:block"
        />
        
        {/* Sidebar - Mobile */}
        <Sidebar 
          user={user}
          className={cn(
            "fixed inset-0 z-40 transform transition-transform duration-300 lg:hidden",
            mobileSidebarOpen ? "translate-x-0" : "-translate-x-full"
          )}
          onClose={() => setMobileSidebarOpen(false)}
          isMobile
        />
        
        {/* Main Content */}
        <main className="w-full lg:pl-64 pb-32">
          <div className="p-4 lg:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
