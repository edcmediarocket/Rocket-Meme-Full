import { Coin, CoinDetail } from "../../client/src/types";

// CoinGecko API endpoints
const API_BASE_URL = "https://api.coingecko.com/api/v3";
const MARKETS_ENDPOINT = `${API_BASE_URL}/coins/markets`;
const COIN_ENDPOINT = `${API_BASE_URL}/coins`;

// Popular coins to show when no specific coins are requested
const DEFAULT_COINS = [
  "bitcoin",
  "ethereum",
  "dogecoin",
  "shiba-inu",
  "solana",
  "binancecoin",
  "cardano",
  "ripple",
  "polkadot",
  "avalanche-2",
  "polygon",
  "chainlink",
  "litecoin",
  "uniswap",
];

/**
 * Fetches coin data from CoinGecko API
 * @param coinIds - Optional list of specific coin IDs to fetch
 * @returns Array of coins with market data
 */
export async function getCoins(coinIds?: string[]): Promise<Coin[]> {
  try {
    // Default parameters
    const params = new URLSearchParams({
      vs_currency: "usd",
      order: "market_cap_desc",
      per_page: "50",
      page: "1",
      sparkline: "false",
      price_change_percentage: "24h",
    });
    
    // If specific coins are requested, use them instead of default settings
    if (coinIds && coinIds.length > 0) {
      params.set("ids", coinIds.join(","));
    }
    
    const response = await fetch(`${MARKETS_ENDPOINT}?${params.toString()}`);
    
    if (!response.ok) {
      // Check if we hit rate limits
      if (response.status === 429) {
        console.warn("CoinGecko API rate limit reached, using fallback data");
        return getFallbackCoins(coinIds);
      }
      
      throw new Error(`CoinGecko API error: ${response.status} ${await response.text()}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching coins:", error);
    return getFallbackCoins(coinIds);
  }
}

/**
 * Fetches detailed information for a specific coin
 * @param coinId - The ID of the coin to fetch
 * @returns Detailed coin information
 */
export async function getCoinDetails(coinId: string): Promise<CoinDetail> {
  try {
    const params = new URLSearchParams({
      localization: "false",
      tickers: "false",
      market_data: "true",
      community_data: "true",
      developer_data: "true",
    });
    
    const response = await fetch(`${COIN_ENDPOINT}/${coinId}?${params.toString()}`);
    
    if (!response.ok) {
      // Check if we hit rate limits
      if (response.status === 429) {
        console.warn("CoinGecko API rate limit reached, using fallback data");
        return getFallbackCoinDetails(coinId);
      }
      
      throw new Error(`CoinGecko API error: ${response.status} ${await response.text()}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching coin details:", error);
    return getFallbackCoinDetails(coinId);
  }
}

/**
 * Fetches historical price data for a specific coin
 * @param coinId - The ID of the coin to fetch
 * @param days - Number of days of historical data to fetch
 * @returns Historical price data
 */
export async function getCoinHistory(coinId: string, days: number = 7): Promise<{ prices: [number, number][] }> {
  try {
    const params = new URLSearchParams({
      vs_currency: "usd",
      days: days.toString(),
    });
    
    const response = await fetch(`${COIN_ENDPOINT}/${coinId}/market_chart?${params.toString()}`);
    
    if (!response.ok) {
      // Check if we hit rate limits
      if (response.status === 429) {
        console.warn("CoinGecko API rate limit reached, using fallback data");
        return getFallbackCoinHistory(coinId, days);
      }
      
      throw new Error(`CoinGecko API error: ${response.status} ${await response.text()}`);
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching coin history:", error);
    return getFallbackCoinHistory(coinId, days);
  }
}

// Fallback data functions in case of API failures

function getFallbackCoins(coinIds?: string[]): Coin[] {
  // Basic fallback data with main coins
  const fallbackCoins: Coin[] = [
    {
      id: "bitcoin",
      symbol: "btc",
      name: "Bitcoin",
      image: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png",
      current_price: 52384.65,
      market_cap: 1080234567890,
      market_cap_rank: 1,
      fully_diluted_valuation: 1100000000000,
      total_volume: 42800000000,
      high_24h: 53000,
      low_24h: 51500,
      price_change_24h: 1254.32,
      price_change_percentage_24h: 2.4,
      market_cap_change_24h: 25000000000,
      market_cap_change_percentage_24h: 2.3,
      circulating_supply: 19500000,
      total_supply: 21000000,
      max_supply: 21000000,
      ath: 69000,
      ath_change_percentage: -24.08,
      ath_date: "2021-11-10T14:24:11.849Z",
      atl: 67.81,
      atl_change_percentage: 77000,
      atl_date: "2013-07-06T00:00:00.000Z",
      last_updated: new Date().toISOString(),
    },
    {
      id: "ethereum",
      symbol: "eth",
      name: "Ethereum",
      image: "https://assets.coingecko.com/coins/images/279/large/ethereum.png",
      current_price: 2954.33,
      market_cap: 354000000000,
      market_cap_rank: 2,
      fully_diluted_valuation: 354000000000,
      total_volume: 18500000000,
      high_24h: 3000,
      low_24h: 2900,
      price_change_24h: 50.12,
      price_change_percentage_24h: 1.7,
      market_cap_change_24h: 6000000000,
      market_cap_change_percentage_24h: 1.6,
      circulating_supply: 120000000,
      total_supply: 120000000,
      max_supply: null,
      ath: 4891.7,
      ath_change_percentage: -39.61,
      ath_date: "2021-11-16T01:09:15.658Z",
      atl: 0.432979,
      atl_change_percentage: 682443.51,
      atl_date: "2015-10-20T00:00:00.000Z",
      last_updated: new Date().toISOString(),
    },
    {
      id: "dogecoin",
      symbol: "doge",
      name: "Dogecoin",
      image: "https://assets.coingecko.com/coins/images/5/large/dogecoin.png",
      current_price: 0.1242,
      market_cap: 17800000000,
      market_cap_rank: 9,
      fully_diluted_valuation: null,
      total_volume: 1800000000,
      high_24h: 0.1255,
      low_24h: 0.1225,
      price_change_24h: -0.00152,
      price_change_percentage_24h: -1.2,
      market_cap_change_24h: -250000000,
      market_cap_change_percentage_24h: -1.3,
      circulating_supply: 143000000000,
      total_supply: null,
      max_supply: null,
      ath: 0.731578,
      ath_change_percentage: -83.03,
      ath_date: "2021-05-08T05:08:23.458Z",
      atl: 0.0000869,
      atl_change_percentage: 142928.84,
      atl_date: "2015-05-06T00:00:00.000Z",
      last_updated: new Date().toISOString(),
    },
    {
      id: "shiba-inu",
      symbol: "shib",
      name: "Shiba Inu",
      image: "https://assets.coingecko.com/coins/images/11939/large/shiba.png",
      current_price: 0.00002845,
      market_cap: 16750000000,
      market_cap_rank: 10,
      fully_diluted_valuation: null,
      total_volume: 884000000,
      high_24h: 0.0000290,
      low_24h: 0.0000275,
      price_change_24h: 0.00000154,
      price_change_percentage_24h: 5.4,
      market_cap_change_24h: 900000000,
      market_cap_change_percentage_24h: 5.3,
      circulating_supply: 589380538750554,
      total_supply: 999991000000000,
      max_supply: null,
      ath: 0.00008616,
      ath_change_percentage: -67.01,
      ath_date: "2021-10-28T03:54:55.568Z",
      atl: 0.000000000056366,
      atl_change_percentage: 50464458.1,
      atl_date: "2020-11-28T11:26:25.668Z",
      last_updated: new Date().toISOString(),
    },
  ];
  
  if (!coinIds || coinIds.length === 0) {
    return fallbackCoins;
  }
  
  // Filter by the requested coin IDs
  return fallbackCoins.filter(coin => coinIds.includes(coin.id));
}

function getFallbackCoinDetails(coinId: string): CoinDetail {
  // Use the fallback coins as a base
  const fallbackCoin = getFallbackCoins([coinId])[0];
  
  if (!fallbackCoin) {
    throw new Error(`Fallback data not available for coin: ${coinId}`);
  }
  
  // Extended data for coin details
  return {
    ...fallbackCoin,
    description: {
      en: coinId === "bitcoin" 
        ? "Bitcoin is the first successful internet money based on peer-to-peer technology; whereby no central bank or authority is involved in the transaction and production of the Bitcoin currency. It was created by an anonymous individual/group under the name, Satoshi Nakamoto. The source code is available publicly as an open source project, anybody can look at it and be part of the developmental process." 
        : coinId === "ethereum"
        ? "Ethereum is a smart contract platform that enables developers to build tokens and decentralized applications (dapps). ETH is the native currency for the Ethereum platform and also works as the transaction fees to miners on the Ethereum network."
        : coinId === "dogecoin"
        ? "Dogecoin (DOGE) is based on the popular \"doge\" Internet meme and features a Shiba Inu on its logo. The open-source digital currency was created by Billy Markus from Portland, Oregon and Jackson Palmer from Sydney, Australia, and was forked from Litecoin in December 2013."
        : "A cryptocurrency with a loyal community following."
    },
    links: {
      homepage: ["https://example.com"],
      blockchain_site: ["https://example.com"],
      official_forum_url: ["https://example.com"],
      chat_url: ["https://example.com"],
      announcement_url: ["https://example.com"],
      twitter_screen_name: "example",
      facebook_username: "example",
      reddit_url: "https://reddit.com/r/example",
      repos_url: { github: ["https://github.com/example"] },
    },
    image: {
      thumb: fallbackCoin.image,
      small: fallbackCoin.image,
      large: fallbackCoin.image,
    },
    market_data: {
      current_price: { usd: fallbackCoin.current_price },
      market_cap: { usd: fallbackCoin.market_cap },
      total_volume: { usd: fallbackCoin.total_volume },
      price_change_percentage_24h: fallbackCoin.price_change_percentage_24h,
      price_change_percentage_7d: 3.5,
      price_change_percentage_30d: 15.2,
      price_change_percentage_1y: 42.8,
    },
    community_data: {
      twitter_followers: 5000000,
      reddit_subscribers: 2000000,
    },
    developer_data: {
      forks: 12000,
      stars: 25000,
      subscribers: 8000,
      total_issues: 3500,
      pull_requests_merged: 9200,
      pull_request_contributors: 450,
      commit_count_4_weeks: 200,
    },
  };
}

function getFallbackCoinHistory(coinId: string, days: number): { prices: [number, number][] } {
  const now = Date.now();
  const prices: [number, number][] = [];
  
  // Create synthetic price data based on coinId
  let basePrice = 0;
  let volatility = 0;
  
  switch (coinId) {
    case "bitcoin":
      basePrice = 50000;
      volatility = 2000;
      break;
    case "ethereum":
      basePrice = 3000;
      volatility = 150;
      break;
    case "dogecoin":
      basePrice = 0.12;
      volatility = 0.01;
      break;
    case "shiba-inu":
      basePrice = 0.000025;
      volatility = 0.000002;
      break;
    default:
      basePrice = 100;
      volatility = 5;
  }
  
  // Generate data points for the specified number of days
  const dataPoints = days * 24; // One point per hour
  const millisecondsPerPoint = (days * 24 * 60 * 60 * 1000) / dataPoints;
  
  for (let i = 0; i < dataPoints; i++) {
    const timestamp = now - (dataPoints - i) * millisecondsPerPoint;
    const randomChange = (Math.random() - 0.5) * volatility;
    const price = basePrice + randomChange;
    prices.push([timestamp, price]);
  }
  
  return { prices };
}
