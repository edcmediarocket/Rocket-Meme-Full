import { AIPrediction } from "../../client/src/types";

/**
 * Get all available AI predictions
 * @returns Array of AI predictions
 */
export async function getPredictions(): Promise<AIPrediction[]> {
  try {
    // Get stored predictions from the database
    const predictions = await import("../storage").then(module => {
      return module.storage.getPredictions();
    });
    
    return predictions;
  } catch (error) {
    console.error("Error getting predictions:", error);
    return [];
  }
}

/**
 * Get AI prediction for a specific coin
 * @param coinId - The ID of the coin
 * @returns AI prediction for the coin, or undefined if not found
 */
export async function getPredictionByCoin(coinId: string): Promise<AIPrediction | undefined> {
  try {
    // Get stored prediction from the database
    const prediction = await import("../storage").then(module => {
      return module.storage.getPredictionByCoinId(coinId);
    });
    
    if (prediction) {
      return prediction;
    }
    
    // If no prediction exists, generate a new one
    return generatePrediction(coinId);
  } catch (error) {
    console.error("Error getting prediction:", error);
    return undefined;
  }
}

/**
 * Generate a new AI prediction for a coin
 * In a real app, this would integrate with OpenAI, TensorFlow, or Hugging Face
 * @param coinId - The ID of the coin
 * @returns New AI prediction
 */
export async function generatePrediction(coinId: string): Promise<AIPrediction | undefined> {
  try {
    // Get current coin data
    const { getCoinDetails } = await import("./coingecko");
    const coin = await getCoinDetails(coinId);
    
    if (!coin) {
      return undefined;
    }
    
    // Determine signal based on recent price trends
    // This is a simplistic algorithm - in a real app, you would use ML models
    const priceChange24h = coin.market_data.price_change_percentage_24h || 0;
    const priceChange7d = coin.market_data.price_change_percentage_7d || 0;
    const priceChange30d = coin.market_data.price_change_percentage_30d || 0;
    
    let signal = "Hold";
    let confidence = 65;
    let riskLevel = "Medium";
    
    if (priceChange24h > 5 && priceChange7d > 10) {
      signal = "Strong Buy";
      confidence = 85;
      riskLevel = priceChange30d > 20 ? "High" : "Medium";
    } else if (priceChange24h > 2 && priceChange7d > 5) {
      signal = "Buy";
      confidence = 75;
      riskLevel = "Medium";
    } else if (priceChange24h < -5 && priceChange7d < -10) {
      signal = "Strong Sell";
      confidence = 80;
      riskLevel = "Medium";
    } else if (priceChange24h < -2 && priceChange7d < -5) {
      signal = "Sell";
      confidence = 70;
      riskLevel = "Medium";
    }
    
    // Randomize confidence a bit to make it look more realistic
    confidence += Math.floor(Math.random() * 10) - 5;
    confidence = Math.max(55, Math.min(95, confidence));
    
    // Calculate price targets based on current price
    const currentPrice = coin.market_data.current_price.usd;
    const shortTermMultiplier = signal.includes("Buy") ? 1.15 : signal.includes("Sell") ? 0.9 : 1.05;
    const longTermMultiplier = signal.includes("Buy") ? 1.35 : signal.includes("Sell") ? 0.8 : 1.1;
    const stopLossMultiplier = signal.includes("Buy") ? 0.92 : signal.includes("Sell") ? 1.08 : 0.95;
    
    // Format prices according to magnitude
    const formatPrice = (price: number): string => {
      if (price < 0.0001) return `$${price.toFixed(8)}`;
      if (price < 0.01) return `$${price.toFixed(6)}`;
      if (price < 1) return `$${price.toFixed(4)}`;
      if (price < 100) return `$${price.toFixed(2)}`;
      if (price < 10000) return `$${price.toFixed(1)}`;
      return `$${Math.round(price).toLocaleString()}`;
    };
    
    const shortTermPrice = formatPrice(currentPrice * shortTermMultiplier);
    const longTermPrice = formatPrice(currentPrice * longTermMultiplier);
    const stopLoss = formatPrice(currentPrice * stopLossMultiplier);
    
    // Generate analysis text based on the signal
    let analysis = "";
    if (signal === "Strong Buy") {
      analysis = `${coin.name} is showing very strong bullish momentum with multiple technical indicators aligning. The recent increase in trading volume and on-chain metrics suggest accumulation by large holders. Consider entering positions with strategic stop-losses.`;
    } else if (signal === "Buy") {
      analysis = `${coin.name} is currently in a positive trend with improving market sentiment. Technical indicators suggest a potential upside in the short to medium term. The asset is showing solid fundamentals and increasing adoption.`;
    } else if (signal === "Hold") {
      analysis = `${coin.name} is in a consolidation phase with mixed signals from technical indicators. The asset is showing moderate volatility and may require close monitoring. Consider maintaining current positions while waiting for clearer market direction.`;
    } else if (signal === "Sell") {
      analysis = `${coin.name} is showing bearish signals with declining momentum. Technical indicators suggest potential downside pressure in the near term. Consider reducing exposure or implementing protective strategies.`;
    } else if (signal === "Strong Sell") {
      analysis = `${coin.name} is exhibiting strong bearish patterns with significant downside momentum. Multiple technical indicators are aligned negatively, and market sentiment has deteriorated. Consider exiting positions to protect capital.`;
    }
    
    // Assign a tier based on the coin's market cap rank
    let requiredTier = "Basic";
    if (coin.market_cap_rank && coin.market_cap_rank <= 5) {
      requiredTier = "Basic";
    } else if (coin.market_cap_rank && coin.market_cap_rank <= 20) {
      requiredTier = "Pro";
    } else {
      requiredTier = "Premium";
    }
    
    // Randomly assign accuracy score between 75-95
    const accuracy = 75 + Math.floor(Math.random() * 20);
    
    // Create the prediction object
    const prediction: Omit<AIPrediction, "id"> = {
      coinId,
      timestamp: new Date().toISOString(),
      signal,
      confidence,
      riskLevel,
      shortTermPrice,
      longTermPrice,
      stopLoss,
      analysis,
      accuracy,
      requiredTier,
    };
    
    // Store the prediction in the database
    return import("../storage").then(module => {
      return module.storage.createPrediction(prediction);
    });
  } catch (error) {
    console.error("Error generating prediction:", error);
    return undefined;
  }
}
