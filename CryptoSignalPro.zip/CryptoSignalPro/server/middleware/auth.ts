import { Request, Response, NextFunction } from "express";
import { storage } from "../storage";

// Extend Express Request type to include userId and session
declare global {
  namespace Express {
    interface Request {
      userId?: number;
      session: {
        userId?: number;
        destroy: (callback: (err: any) => void) => void;
      } & Record<string, any>;
    }
  }
}

/**
 * Authentication middleware
 * Checks if the user is logged in via session
 */
export async function authenticate(req: Request, res: Response, next: NextFunction) {
  try {
    // In development mode, allow access and set a default user ID
    if (process.env.NODE_ENV === 'development') {
      // Set a default userId for development
      req.userId = 1;
      return next();
    }
    
    // Check if user is logged in via session
    if (req.session && req.session.userId) {
      // Set userId on request object for use in route handlers
      req.userId = req.session.userId;
      
      // Make sure the user exists
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      return next();
    }
    
    // No valid session found
    return res.status(401).json({ message: "Authentication required" });
  } catch (error) {
    console.error("Auth middleware error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
}

/**
 * Admin authorization middleware
 * Checks if the user is an admin
 * Must be used after authenticate middleware
 */
export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  try {
    // In development mode, allow admin access
    if (process.env.NODE_ENV === 'development') {
      return next();
    }
    
    if (!req.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    // Check if user is an admin
    const user = await storage.getUser(req.userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    next();
  } catch (error) {
    console.error("Admin middleware error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
}
