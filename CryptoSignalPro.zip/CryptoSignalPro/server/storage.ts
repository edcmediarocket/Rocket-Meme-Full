import { 
  users, type User, type InsertUser,
  watchlist, type Watchlist, type InsertWatchlist,
  predictions, type Prediction, type InsertPrediction,
  whaleAlerts, type WhaleAlert, type InsertWhaleAlert,
  alerts, type Alert, type InsertAlert
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

// Complete CRUD interface for all entities
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: Omit<InsertUser, "id" | "createdAt">): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  updateUserLastLogin(id: number): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Watchlist methods
  getWatchlistByUserId(userId: number): Promise<Watchlist[]>;
  getWatchlistItem(userId: number, coinId: string): Promise<Watchlist | undefined>;
  addToWatchlist(item: InsertWatchlist): Promise<Watchlist>;
  removeFromWatchlist(userId: number, coinId: string): Promise<void>;
  
  // Prediction methods
  getPredictions(): Promise<Prediction[]>;
  getPredictionByCoinId(coinId: string): Promise<Prediction | undefined>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;
  updatePrediction(id: number, data: Partial<Prediction>): Promise<Prediction>;
  
  // Whale Alert methods
  getWhaleAlerts(limit?: number): Promise<WhaleAlert[]>;
  getWhaleAlertsByToken(token: string, limit?: number): Promise<WhaleAlert[]>;
  createWhaleAlert(alert: InsertWhaleAlert): Promise<WhaleAlert>;
  
  // User Alert methods
  getAlertsByUserId(userId: number): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: number, data: Partial<Alert>): Promise<Alert>;
  deleteAlert(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private watchlistItems: Map<number, Watchlist>;
  private predictionItems: Map<number, Prediction>;
  private whaleAlertItems: Map<number, WhaleAlert>;
  private alertItems: Map<number, Alert>;
  
  private userId: number = 1;
  private watchlistId: number = 1;
  private predictionId: number = 1;
  private whaleAlertId: number = 1;
  private alertId: number = 1;

  constructor() {
    this.users = new Map();
    this.watchlistItems = new Map();
    this.predictionItems = new Map();
    this.whaleAlertItems = new Map();
    this.alertItems = new Map();
    
    // Add admin user
    this.createUser({
      username: "admin",
      email: "admin@rocketmeme.com",
      password: "admin123",
      displayName: "Admin User",
      isAdmin: true,
      subscriptionTier: "Premium"
    });
    
    // Add some sample predictions
    this.createPrediction({
      coinId: "bitcoin",
      signal: "Strong Buy",
      confidence: 87,
      riskLevel: "Medium",
      shortTermPrice: "$56,500",
      longTermPrice: "$62,000",
      stopLoss: "$49,200",
      analysis: "Bitcoin shows strong momentum with increased whale activity and positive market sentiment. Technical indicators suggest continued upward movement with resistance at $58,000.",
      accuracy: 92,
      requiredTier: "Basic"
    });
    
    this.createPrediction({
      coinId: "ethereum",
      signal: "Buy",
      confidence: 72,
      riskLevel: "Medium",
      shortTermPrice: "$3,200",
      longTermPrice: "$3,850",
      stopLoss: "$2,750",
      analysis: "Ethereum shows positive momentum ahead of upcoming protocol changes. Smart money flow indicates accumulation and technical indicators show potential breakout.",
      accuracy: 85,
      requiredTier: "Pro"
    });
    
    this.createPrediction({
      coinId: "dogecoin",
      signal: "Hold",
      confidence: 65,
      riskLevel: "High",
      shortTermPrice: "$0.128",
      longTermPrice: "$0.155",
      stopLoss: "$0.107",
      analysis: "Dogecoin is in a consolidation phase with potential for breakout based on social sentiment analysis. Monitor for increased whale activity which could signal future movement.",
      accuracy: 78,
      requiredTier: "Pro"
    });
    
    this.createPrediction({
      coinId: "shiba-inu",
      signal: "Strong Buy",
      confidence: 81,
      riskLevel: "High",
      shortTermPrice: "$0.00003250",
      longTermPrice: "$0.00004100",
      stopLoss: "$0.00002450",
      analysis: "Shiba Inu is showing bullish patterns with increasing buy pressure. Recent developments in the ecosystem and growing community interest suggest potential for significant upward movement.",
      accuracy: 83,
      requiredTier: "Premium"
    });
    
    // Add some sample whale alerts
    this.createWhaleAlert({
      transactionId: "tx1",
      token: "BTC",
      amount: "1,250 BTC",
      amountUsd: "$65,480,812",
      fromAddress: "0x7a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b",
      toAddress: "0x8c5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f0a9b8c7d",
      fromLabel: "Binance",
      toLabel: null,
      timestamp: new Date().toISOString(),
      transactionType: "Exchange Withdrawal",
      blockchain: "Bitcoin",
      requiredTier: "Basic"
    });
    
    this.createWhaleAlert({
      transactionId: "tx2",
      token: "ETH",
      amount: "8,500 ETH",
      amountUsd: "$25,111,805",
      fromAddress: "0x4b3a2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b",
      toAddress: "0x9f1e8d7c6b5a4e3d2c1b0a9f8e7d6c5b4a3f2e1d",
      fromLabel: null,
      toLabel: "Kraken",
      timestamp: new Date().toISOString(),
      transactionType: "Exchange Deposit",
      blockchain: "Ethereum",
      requiredTier: "Basic"
    });
    
    this.createWhaleAlert({
      transactionId: "tx3",
      token: "SHIB",
      amount: "42,500,000,000 SHIB",
      amountUsd: "$1,209,125",
      fromAddress: "0x2f8a9c7b6d5e4f3a2c1b0d9e8f7a6b5c4d3e2f1a",
      toAddress: "0x6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b",
      fromLabel: "Coinbase",
      toLabel: null,
      timestamp: new Date().toISOString(),
      transactionType: "Exchange Withdrawal",
      blockchain: "Ethereum",
      requiredTier: "Pro"
    });
    
    // Add more whale alerts with different tokens
    this.createWhaleAlert({
      transactionId: "tx4",
      token: "BTC",
      amount: "850 BTC",
      amountUsd: "$44,526,650",
      fromAddress: "0x1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b",
      toAddress: "0x3c5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f0a9b8c7d",
      fromLabel: null,
      toLabel: "Binance",
      timestamp: new Date().toISOString(),
      transactionType: "Exchange Deposit",
      blockchain: "Bitcoin",
      requiredTier: "Pro"
    });
    
    this.createWhaleAlert({
      transactionId: "tx5",
      token: "ETH",
      amount: "12,000 ETH",
      amountUsd: "$35,451,960",
      fromAddress: "0x5b3a2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b",
      toAddress: "0x0f1e8d7c6b5a4e3d2c1b0a9f8e7d6c5b4a3f2e1d",
      fromLabel: "Kraken",
      toLabel: null,
      timestamp: new Date().toISOString(),
      transactionType: "Exchange Withdrawal",
      blockchain: "Ethereum",
      requiredTier: "Premium"
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(userData: Partial<User>): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    
    const user: User = {
      id,
      username: userData.username!,
      email: userData.email!,
      password: userData.password!,
      displayName: userData.displayName || null,
      avatarUrl: userData.avatarUrl || null,
      subscriptionTier: userData.subscriptionTier || "Basic",
      subscriptionId: userData.subscriptionId || null,
      lastLogin: userData.lastLogin || now,
      isAdmin: userData.isAdmin || false,
      createdAt: now,
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    
    return updatedUser;
  }

  async updateUserLastLogin(id: number): Promise<User> {
    return this.updateUser(id, { lastLogin: new Date() });
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Watchlist methods
  async getWatchlistByUserId(userId: number): Promise<Watchlist[]> {
    return Array.from(this.watchlistItems.values()).filter(
      (item) => item.userId === userId,
    );
  }

  async getWatchlistItem(userId: number, coinId: string): Promise<Watchlist | undefined> {
    return Array.from(this.watchlistItems.values()).find(
      (item) => item.userId === userId && item.coinId === coinId,
    );
  }

  async addToWatchlist(item: InsertWatchlist): Promise<Watchlist> {
    const id = this.watchlistId++;
    const now = new Date();
    
    const watchlistItem: Watchlist = {
      id,
      userId: item.userId,
      coinId: item.coinId,
      addedAt: now,
    };
    
    this.watchlistItems.set(id, watchlistItem);
    return watchlistItem;
  }

  async removeFromWatchlist(userId: number, coinId: string): Promise<void> {
    for (const [id, item] of this.watchlistItems.entries()) {
      if (item.userId === userId && item.coinId === coinId) {
        this.watchlistItems.delete(id);
        return;
      }
    }
  }

  // Prediction methods
  async getPredictions(): Promise<Prediction[]> {
    return Array.from(this.predictionItems.values());
  }

  async getPredictionByCoinId(coinId: string): Promise<Prediction | undefined> {
    return Array.from(this.predictionItems.values()).find(
      (item) => item.coinId === coinId,
    );
  }

  async createPrediction(predictionData: Omit<InsertPrediction, "id" | "timestamp">): Promise<Prediction> {
    const id = this.predictionId++;
    const now = new Date();
    
    const prediction: Prediction = {
      id,
      coinId: predictionData.coinId,
      timestamp: now.toISOString(),
      signal: predictionData.signal,
      confidence: predictionData.confidence,
      riskLevel: predictionData.riskLevel,
      shortTermPrice: predictionData.shortTermPrice,
      longTermPrice: predictionData.longTermPrice,
      stopLoss: predictionData.stopLoss,
      analysis: predictionData.analysis,
      accuracy: predictionData.accuracy || 0,
      requiredTier: predictionData.requiredTier || "Basic",
    };
    
    this.predictionItems.set(id, prediction);
    return prediction;
  }

  async updatePrediction(id: number, data: Partial<Prediction>): Promise<Prediction> {
    const prediction = this.predictionItems.get(id);
    if (!prediction) {
      throw new Error("Prediction not found");
    }
    
    const updatedPrediction = { ...prediction, ...data };
    this.predictionItems.set(id, updatedPrediction);
    
    return updatedPrediction;
  }

  // Whale Alert methods
  async getWhaleAlerts(limit: number = 10): Promise<WhaleAlert[]> {
    const alerts = Array.from(this.whaleAlertItems.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return alerts.slice(0, limit);
  }

  async getWhaleAlertsByToken(token: string, limit: number = 10): Promise<WhaleAlert[]> {
    const alerts = Array.from(this.whaleAlertItems.values())
      .filter((alert) => alert.token.toLowerCase() === token.toLowerCase())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return alerts.slice(0, limit);
  }

  async createWhaleAlert(alertData: Omit<InsertWhaleAlert, "id">): Promise<WhaleAlert> {
    const id = this.whaleAlertId++;
    
    const alert: WhaleAlert = {
      id,
      transactionId: alertData.transactionId,
      token: alertData.token,
      amount: alertData.amount,
      amountUsd: alertData.amountUsd,
      fromAddress: alertData.fromAddress,
      toAddress: alertData.toAddress,
      fromLabel: alertData.fromLabel,
      toLabel: alertData.toLabel,
      timestamp: alertData.timestamp,
      transactionType: alertData.transactionType,
      blockchain: alertData.blockchain,
      requiredTier: alertData.requiredTier || "Basic",
    };
    
    this.whaleAlertItems.set(id, alert);
    return alert;
  }

  // User Alert methods
  async getAlertsByUserId(userId: number): Promise<Alert[]> {
    return Array.from(this.alertItems.values()).filter(
      (item) => item.userId === userId,
    );
  }

  async createAlert(alertData: Omit<InsertAlert, "id" | "createdAt">): Promise<Alert> {
    const id = this.alertId++;
    const now = new Date();
    
    const alert: Alert = {
      id,
      userId: alertData.userId,
      coinId: alertData.coinId,
      alertType: alertData.alertType,
      threshold: alertData.threshold,
      active: alertData.active || true,
      createdAt: now,
    };
    
    this.alertItems.set(id, alert);
    return alert;
  }

  async updateAlert(id: number, data: Partial<Alert>): Promise<Alert> {
    const alert = this.alertItems.get(id);
    if (!alert) {
      throw new Error("Alert not found");
    }
    
    const updatedAlert = { ...alert, ...data };
    this.alertItems.set(id, updatedAlert);
    
    return updatedAlert;
  }

  async deleteAlert(id: number): Promise<void> {
    if (!this.alertItems.has(id)) {
      throw new Error("Alert not found");
    }
    
    this.alertItems.delete(id);
  }
}

// Database implementation of storage interface
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    try {
      const { db } = await import("./db");
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error("Error getting user:", error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const { db } = await import("./db");
      const [user] = await db.select().from(users).where(eq(users.username, username));
      return user;
    } catch (error) {
      console.error("Error getting user by username:", error);
      return undefined;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const { db } = await import("./db");
      const [user] = await db.select().from(users).where(eq(users.email, email));
      return user;
    } catch (error) {
      console.error("Error getting user by email:", error);
      return undefined;
    }
  }

  async createUser(userData: Omit<InsertUser, "id" | "createdAt">): Promise<User> {
    try {
      const { db } = await import("./db");
      const [user] = await db.insert(users)
        .values({
          ...userData,
          isAdmin: false,
          createdAt: new Date()
        })
        .returning();
      return user;
    } catch (error) {
      console.error("Error creating user:", error);
      throw error;
    }
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    try {
      const { db } = await import("./db");
      const [updatedUser] = await db.update(users)
        .set(data)
        .where(eq(users.id, id))
        .returning();
      
      if (!updatedUser) {
        throw new Error("User not found");
      }
      
      return updatedUser;
    } catch (error) {
      console.error("Error updating user:", error);
      throw error;
    }
  }

  async updateUserLastLogin(id: number): Promise<User> {
    return this.updateUser(id, { lastLogin: new Date() });
  }

  async getAllUsers(): Promise<User[]> {
    try {
      const { db } = await import("./db");
      const users = await db.select().from(users);
      return users;
    } catch (error) {
      console.error("Error getting all users:", error);
      return [];
    }
  }

  async getWatchlistByUserId(userId: number): Promise<Watchlist[]> {
    try {
      const { db } = await import("./db");
      const watchlistItems = await db.select()
        .from(watchlist)
        .where(eq(watchlist.userId, userId));
      return watchlistItems;
    } catch (error) {
      console.error("Error getting watchlist:", error);
      return [];
    }
  }

  async getWatchlistItem(userId: number, coinId: string): Promise<Watchlist | undefined> {
    try {
      const { db } = await import("./db");
      const [item] = await db.select()
        .from(watchlist)
        .where(and(
          eq(watchlist.userId, userId),
          eq(watchlist.coinId, coinId)
        ));
      return item;
    } catch (error) {
      console.error("Error getting watchlist item:", error);
      return undefined;
    }
  }

  async addToWatchlist(item: InsertWatchlist): Promise<Watchlist> {
    try {
      const { db } = await import("./db");
      const [watchlistItem] = await db.insert(watchlist)
        .values({
          ...item,
          addedAt: new Date()
        })
        .returning();
      return watchlistItem;
    } catch (error) {
      console.error("Error adding to watchlist:", error);
      throw error;
    }
  }

  async removeFromWatchlist(userId: number, coinId: string): Promise<void> {
    try {
      const { db } = await import("./db");
      await db.delete(watchlist)
        .where(and(
          eq(watchlist.userId, userId),
          eq(watchlist.coinId, coinId)
        ));
    } catch (error) {
      console.error("Error removing from watchlist:", error);
      throw error;
    }
  }

  async getPredictions(): Promise<Prediction[]> {
    try {
      const { db } = await import("./db");
      const predictionItems = await db.select().from(predictions);
      return predictionItems;
    } catch (error) {
      console.error("Error getting predictions:", error);
      return [];
    }
  }

  async getPredictionByCoinId(coinId: string): Promise<Prediction | undefined> {
    try {
      const { db } = await import("./db");
      const [prediction] = await db.select()
        .from(predictions)
        .where(eq(predictions.coinId, coinId))
        .orderBy(desc(predictions.timestamp))
        .limit(1);
      return prediction;
    } catch (error) {
      console.error("Error getting prediction:", error);
      return undefined;
    }
  }

  async createPrediction(predictionData: Omit<InsertPrediction, "id" | "timestamp">): Promise<Prediction> {
    try {
      const { db } = await import("./db");
      const [prediction] = await db.insert(predictions)
        .values({
          ...predictionData,
          timestamp: new Date()
        })
        .returning();
      return prediction;
    } catch (error) {
      console.error("Error creating prediction:", error);
      throw error;
    }
  }

  async updatePrediction(id: number, data: Partial<Prediction>): Promise<Prediction> {
    try {
      const { db } = await import("./db");
      const [updatedPrediction] = await db.update(predictions)
        .set(data)
        .where(eq(predictions.id, id))
        .returning();
      
      if (!updatedPrediction) {
        throw new Error("Prediction not found");
      }
      
      return updatedPrediction;
    } catch (error) {
      console.error("Error updating prediction:", error);
      throw error;
    }
  }

  async getWhaleAlerts(limit: number = 10): Promise<WhaleAlert[]> {
    try {
      const { db } = await import("./db");
      const alerts = await db.select()
        .from(whaleAlerts)
        .orderBy(desc(whaleAlerts.timestamp))
        .limit(limit);
      return alerts;
    } catch (error) {
      console.error("Error getting whale alerts:", error);
      return [];
    }
  }

  async getWhaleAlertsByToken(token: string, limit: number = 10): Promise<WhaleAlert[]> {
    try {
      const { db } = await import("./db");
      const alerts = await db.select()
        .from(whaleAlerts)
        .where(eq(whaleAlerts.token, token))
        .orderBy(desc(whaleAlerts.timestamp))
        .limit(limit);
      return alerts;
    } catch (error) {
      console.error("Error getting whale alerts by token:", error);
      return [];
    }
  }

  async createWhaleAlert(alertData: Omit<InsertWhaleAlert, "id">): Promise<WhaleAlert> {
    try {
      const { db } = await import("./db");
      const [alert] = await db.insert(whaleAlerts)
        .values(alertData)
        .returning();
      return alert;
    } catch (error) {
      console.error("Error creating whale alert:", error);
      throw error;
    }
  }

  async getAlertsByUserId(userId: number): Promise<Alert[]> {
    try {
      const { db } = await import("./db");
      const userAlerts = await db.select()
        .from(alerts)
        .where(eq(alerts.userId, userId));
      return userAlerts;
    } catch (error) {
      console.error("Error getting user alerts:", error);
      return [];
    }
  }

  async createAlert(alertData: Omit<InsertAlert, "id" | "createdAt">): Promise<Alert> {
    try {
      const { db } = await import("./db");
      const [alert] = await db.insert(alerts)
        .values({
          ...alertData,
          createdAt: new Date()
        })
        .returning();
      return alert;
    } catch (error) {
      console.error("Error creating alert:", error);
      throw error;
    }
  }

  async updateAlert(id: number, data: Partial<Alert>): Promise<Alert> {
    try {
      const { db } = await import("./db");
      const [updatedAlert] = await db.update(alerts)
        .set(data)
        .where(eq(alerts.id, id))
        .returning();
      
      if (!updatedAlert) {
        throw new Error("Alert not found");
      }
      
      return updatedAlert;
    } catch (error) {
      console.error("Error updating alert:", error);
      throw error;
    }
  }

  async deleteAlert(id: number): Promise<void> {
    try {
      const { db } = await import("./db");
      await db.delete(alerts)
        .where(eq(alerts.id, id));
    } catch (error) {
      console.error("Error deleting alert:", error);
      throw error;
    }
  }
}

// Export database storage instance
export const storage = new DatabaseStorage();
