import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Project download route
  app.get('/api/download-project', async (req, res) => {
  try {
    // Create project files object
    const projectFiles = {
      // Add your project files here
      'package.json': JSON.stringify(require('../package.json'), null, 2),
      'README.md': '# My Replit Project\n\nProject documentation goes here.',
      // Add more files as needed
    };
    
    res.json({ files: projectFiles });
  } catch (error) {
    res.status(500).json({ error: 'Failed to gather project files' });
  }
});

import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { getCoins, getCoinDetails, getCoinHistory } from "./services/coingecko";
import { getWhaleAlerts, getWhaleAlertsByToken } from "./services/whalealert";
import { getPredictions, getPredictionByCoin } from "./services/ai-prediction";
import { authenticate, requireAdmin } from "./middleware/auth";
import { z } from "zod";
import { loginSchema, registerSchema, subscriptionTiers } from "@shared/schema";

// PayPal plan IDs from the requirements
const PAYPAL_PLAN_IDS = {
  Basic: "P-1G079065XJ172161KNAQPHQQ",
  Pro: "5GK21636B1377881VNAQPMFA",
  Premium: "66R88029R2506591NNAQPPKQ",
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validated = registerSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByUsername(validated.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(validated.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      const user = await storage.createUser({
        ...validated,
        subscriptionTier: "Basic",
        lastLogin: new Date(),
      });
      
      // Set user session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      return res.status(201).json({ 
        id: user.id,
        username: user.username,
        email: user.email,
        subscriptionTier: user.subscriptionTier,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validated = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(validated.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // In a real app, we would hash and compare passwords
      if (user.password !== validated.password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Update last login
      await storage.updateUserLastLogin(user.id);
      
      // Set user session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      return res.json({ 
        id: user.id,
        username: user.username,
        email: user.email,
        subscriptionTier: user.subscriptionTier,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      return res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ message: "Logout failed" });
        }
        res.clearCookie("connect.sid");
        return res.status(200).json({ message: "Logged out successfully" });
      });
    } else {
      return res.status(200).json({ message: "No active session" });
    }
  });

  // Firebase Auth Integration
  app.post("/api/auth/firebase", async (req, res) => {
    const { email, uid, displayName } = req.body;
    
    if (!email || !uid) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    try {
      // Check if user exists
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Create new user with Firebase credentials
        const username = email.split('@')[0] + '_' + Math.floor(Math.random() * 1000);
        user = await storage.createUser({
          username,
          email,
          password: uid, // Store Firebase UID as password (not actually used for auth)
          displayName: displayName || username,
          subscriptionTier: "Basic",
          lastLogin: new Date(),
        });
      }
      
      // Update last login
      await storage.updateUserLastLogin(user.id);
      
      // Set user session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      return res.status(200).json({ 
        id: user.id,
        username: user.username,
        email: user.email,
        displayName: user.displayName,
        subscriptionTier: user.subscriptionTier,
      });
    } catch (error) {
      console.error("Firebase auth error:", error);
      return res.status(500).json({ message: "Authentication failed" });
    }
  });

  // User routes
  app.get("/api/user/profile", async (req, res) => {
    // For development mode, allow testing without authentication
    if (process.env.NODE_ENV === "development" && !req.userId) {
      // Return a dummy user for development
      return res.json({
        id: 1,
        username: "demo_user",
        email: "demo@example.com",
        displayName: "Demo User",
        avatarUrl: null,
        subscriptionTier: "Pro",
        subscriptionId: null,
        lastLogin: new Date().toISOString(),
        isAdmin: true,
        createdAt: new Date().toISOString(),
      });
    }
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send password to client
      const { password, ...userWithoutPassword } = user;
      
      return res.json(userWithoutPassword);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  app.patch("/api/user/profile", authenticate, async (req, res) => {
    try {
      const allowedFields = ["displayName", "avatarUrl"];
      const updateData: Record<string, any> = {};
      
      // Only allow specific fields to be updated
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      }
      
      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }
      
      const updatedUser = await storage.updateUser(req.userId!, updateData);
      
      // Don't send password to client
      const { password, ...userWithoutPassword } = updatedUser;
      
      return res.json(userWithoutPassword);
    } catch (error) {
      return res.status(500).json({ message: "Failed to update user profile" });
    }
  });

  app.get("/api/user/subscription", async (req, res) => {
    // For development mode, allow testing without authentication
    if (process.env.NODE_ENV === "development" && !req.userId) {
      return res.json({
        tier: "Pro",
        subscriptionId: null
      });
    }
    try {
      const user = await storage.getUser(req.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.json({
        tier: user.subscriptionTier,
        subscriptionId: user.subscriptionId,
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  // Watchlist routes
  app.get("/api/user/watchlist", async (req, res) => {
    // For development mode, return an empty array without authentication
    if (process.env.NODE_ENV === "development" && !req.userId) {
      return res.json([]);
    }
    try {
      const watchlist = await storage.getWatchlistByUserId(req.userId!);
      
      // If watchlist is empty, return empty array
      if (!watchlist || watchlist.length === 0) {
        return res.json([]);
      }
      
      // Get coin details for each coin in watchlist
      const coinIds = watchlist.map(item => item.coinId);
      const coins = await getCoins(coinIds);
      
      return res.json(coins);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch watchlist" });
    }
  });

  app.post("/api/user/watchlist", authenticate, async (req, res) => {
    try {
      const { coinId } = req.body;
      
      if (!coinId) {
        return res.status(400).json({ message: "Missing coinId" });
      }
      
      // Check if already in watchlist
      const existing = await storage.getWatchlistItem(req.userId!, coinId);
      if (existing) {
        return res.status(400).json({ message: "Coin already in watchlist" });
      }
      
      await storage.addToWatchlist({
        userId: req.userId!,
        coinId,
      });
      
      return res.status(201).json({ message: "Added to watchlist" });
    } catch (error) {
      return res.status(500).json({ message: "Failed to add to watchlist" });
    }
  });

  app.delete("/api/user/watchlist/:coinId", authenticate, async (req, res) => {
    try {
      const { coinId } = req.params;
      
      await storage.removeFromWatchlist(req.userId!, coinId);
      
      return res.json({ message: "Removed from watchlist" });
    } catch (error) {
      return res.status(500).json({ message: "Failed to remove from watchlist" });
    }
  });

  // Crypto data routes
  app.get("/api/coins", async (req, res) => {
    try {
      const coins = await getCoins();
      return res.json(coins);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch coins" });
    }
  });

  app.get("/api/coins/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const coin = await getCoinDetails(id);
      return res.json(coin);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch coin details" });
    }
  });

  app.get("/api/coins/:id/history", async (req, res) => {
    try {
      const { id } = req.params;
      const days = req.query.days ? parseInt(req.query.days as string) : 7;
      
      const history = await getCoinHistory(id, days);
      return res.json(history);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch coin history" });
    }
  });

  // AI Predictions
  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await getPredictions();
      return res.json(predictions);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch predictions" });
    }
  });

  app.get("/api/predictions/:coinId", async (req, res) => {
    try {
      const { coinId } = req.params;
      const prediction = await getPredictionByCoin(coinId);
      
      if (!prediction) {
        return res.status(404).json({ message: "No prediction found for this coin" });
      }
      
      return res.json(prediction);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch prediction" });
    }
  });

  // Whale Alerts
  app.get("/api/whale-alerts", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      if (req.query.token) {
        const token = req.query.token as string;
        const alerts = await getWhaleAlertsByToken(token, limit);
        return res.json(alerts);
      } else {
        const alerts = await getWhaleAlerts(limit);
        return res.json(alerts);
      }
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch whale alerts" });
    }
  });

  // Converter/Calculator
  app.get("/api/calculator/convert", async (req, res) => {
    try {
      const { from, to, amount } = req.query;
      
      if (!from || !to || !amount) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      const parsedAmount = parseFloat(amount as string);
      
      if (isNaN(parsedAmount)) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      // Simplified conversion logic
      // For a real app, we would get exchange rates from an API
      const fiatRates: Record<string, number> = {
        "USD": 1,
        "EUR": 0.93,
        "JPY": 150.3,
        "GBP": 0.79,
        "AUD": 1.53
      };
      
      const isFiatFrom = Object.keys(fiatRates).includes(from as string);
      const isFiatTo = Object.keys(fiatRates).includes(to as string);
      
      let convertedAmount: number;
      
      if (isFiatFrom && isFiatTo) {
        // Fiat to fiat
        convertedAmount = parsedAmount * (fiatRates[to as string] / fiatRates[from as string]);
      } else if (isFiatFrom) {
        // Fiat to crypto - need price data
        const coins = await getCoins();
        const targetCoin = coins.find(c => 
          c.symbol.toLowerCase() === (to as string).toLowerCase() ||
          c.id.toLowerCase() === (to as string).toLowerCase()
        );
        
        if (!targetCoin) {
          return res.status(404).json({ message: "Target currency not found" });
        }
        
        convertedAmount = parsedAmount / targetCoin.current_price;
      } else if (isFiatTo) {
        // Crypto to fiat
        const coins = await getCoins();
        const sourceCoin = coins.find(c => 
          c.symbol.toLowerCase() === (from as string).toLowerCase() ||
          c.id.toLowerCase() === (from as string).toLowerCase()
        );
        
        if (!sourceCoin) {
          return res.status(404).json({ message: "Source currency not found" });
        }
        
        convertedAmount = parsedAmount * sourceCoin.current_price;
      } else {
        // Crypto to crypto
        const coins = await getCoins();
        const sourceCoin = coins.find(c => 
          c.symbol.toLowerCase() === (from as string).toLowerCase() ||
          c.id.toLowerCase() === (from as string).toLowerCase()
        );
        const targetCoin = coins.find(c => 
          c.symbol.toLowerCase() === (to as string).toLowerCase() ||
          c.id.toLowerCase() === (to as string).toLowerCase()
        );
        
        if (!sourceCoin || !targetCoin) {
          return res.status(404).json({ message: "Currency not found" });
        }
        
        convertedAmount = parsedAmount * (sourceCoin.current_price / targetCoin.current_price);
      }
      
      return res.json({ amount: convertedAmount });
    } catch (error) {
      return res.status(500).json({ message: "Failed to convert currencies" });
    }
  });

  // Admin routes
  app.get("/api/admin/users", authenticate, requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Don't send passwords to client
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      return res.json(usersWithoutPasswords);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch("/api/admin/users/:id/subscription", authenticate, requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { tier } = req.body;
      
      if (!tier || !subscriptionTiers.includes(tier)) {
        return res.status(400).json({ message: "Invalid subscription tier" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, { subscriptionTier: tier });
      
      // Don't send password to client
      const { password, ...userWithoutPassword } = updatedUser;
      
      return res.json(userWithoutPassword);
    } catch (error) {
      return res.status(500).json({ message: "Failed to update user subscription" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

  // Subscription plans
  app.get("/api/subscriptions/plans", async (req, res) => {
    try {
      const plans = [
        {
          id: "basic",
          name: "Basic",
          price: 9.99,
          currency: "USD",
          paypalPlanId: PAYPAL_PLAN_IDS.Basic,
          features: {
            included: [
              "Real-time crypto data",
              "Basic market analytics",
              "Conversion calculator",
              "Watchlist (up to 5 coins)"
            ],
            excluded: [
              "Advanced AI predictions",
              "Exclusive whale alerts",
              "Priority support"
            ]
          }
        },
        {
          id: "pro",
          name: "Pro",
          price: 24.99,
          currency: "USD",
          paypalPlanId: PAYPAL_PLAN_IDS.Pro,
          popular: true,
          features: {
            included: [
              "Everything in Basic plan",
              "AI-driven buy/sell signals",
              "Real-time whale alerts",
              "Price prediction with accuracy metrics",
              "Watchlist (unlimited coins)",
              "Push notifications"
            ],
            excluded: [
              "Priority support"
            ]
          }
        },
        {
          id: "premium",
          name: "Premium",
          price: 49.99,
          currency: "USD",
          paypalPlanId: PAYPAL_PLAN_IDS.Premium,
          premium: true,
          features: {
            included: [
              "Everything in Pro plan",
              "Advanced AI trend analysis",
              "Exclusive market reports",
              "Early access to new features",
              "Custom alert configurations",
              "Portfolio performance analytics",
              "24/7 Priority support"
            ],
            excluded: []
          }
        }
      ];
      
      return res.json(plans);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch subscription plans" });
    }
  });

  // PayPal routes
  app.get("/api/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/api/paypal/order", async (req, res) => {
    await createPaypalOrder(req, res);
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    // Use the PayPal capture function directly
    await capturePaypalOrder(req, res);
    // User subscription update is now handled in the frontend after payment success
  });

  const httpServer = createServer(app);
  return httpServer;
}
