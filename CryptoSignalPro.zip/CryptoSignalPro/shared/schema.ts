import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User Management
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  avatarUrl: text("avatar_url"),
  subscriptionTier: text("subscription_tier").default("Basic").notNull(),
  subscriptionId: text("subscription_id"),
  lastLogin: timestamp("last_login"),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User's watchlist
export const watchlist = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  coinId: text("coin_id").notNull(),
  addedAt: timestamp("added_at").defaultNow().notNull(),
});

// AI Predictions
export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  coinId: text("coin_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  signal: text("signal").notNull(), // "Buy", "Sell", "Hold", "Strong Buy", "Strong Sell"
  confidence: integer("confidence").notNull(), // 0-100 percentage
  riskLevel: text("risk_level").notNull(), // "Low", "Medium", "High"
  shortTermPrice: text("short_term_price"),
  longTermPrice: text("long_term_price"),
  stopLoss: text("stop_loss"),
  analysis: text("analysis"),
  accuracy: integer("accuracy"), // 0-100 percentage
  requiredTier: text("required_tier").default("Basic").notNull(), // "Basic", "Pro", "Premium"
});

// Whale Alerts
export const whaleAlerts = pgTable("whale_alerts", {
  id: serial("id").primaryKey(),
  transactionId: text("transaction_id").notNull().unique(),
  token: text("token").notNull(),
  amount: text("amount").notNull(),
  amountUsd: text("amount_usd").notNull(),
  fromAddress: text("from_address").notNull(),
  toAddress: text("to_address").notNull(),
  fromLabel: text("from_label"),
  toLabel: text("to_label"),
  timestamp: timestamp("timestamp").notNull(),
  transactionType: text("transaction_type"), // "Exchange Deposit", "Exchange Withdrawal", "Unknown"
  blockchain: text("blockchain").notNull(),
  requiredTier: text("required_tier").default("Basic").notNull(), // "Basic", "Pro", "Premium"
});

// User alerts/notifications
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  coinId: text("coin_id"),
  alertType: text("alert_type").notNull(), // "Price", "Whale", "Prediction"
  threshold: text("threshold"), // Price threshold or other condition
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Schema for insert operations
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  isAdmin: true,
  createdAt: true
});

export const insertWatchlistSchema = createInsertSchema(watchlist).omit({ 
  id: true, 
  addedAt: true 
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({ 
  id: true, 
  timestamp: true
});

export const insertWhaleAlertSchema = createInsertSchema(whaleAlerts).omit({ 
  id: true 
});

export const insertAlertSchema = createInsertSchema(alerts).omit({ 
  id: true,
  createdAt: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Watchlist = typeof watchlist.$inferSelect;
export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;

export type WhaleAlert = typeof whaleAlerts.$inferSelect;
export type InsertWhaleAlert = z.infer<typeof insertWhaleAlertSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

// Subscription tiers
export const subscriptionTiers = ["Basic", "Pro", "Premium"] as const;
export type SubscriptionTier = typeof subscriptionTiers[number];

// Auth schemas
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const registerSchema = z.object({
  username: z.string().min(3).max(50),
  email: z.string().email(),
  password: z.string().min(6),
  displayName: z.string().optional(),
});
